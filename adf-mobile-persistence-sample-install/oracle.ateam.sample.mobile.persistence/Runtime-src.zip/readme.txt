ADF Mobile Persistence Sample
=============================
This sample code is provided "as-is". There is no support available.
Use is at own risk. This code has not been tested extensively, and has not been used in production applications.