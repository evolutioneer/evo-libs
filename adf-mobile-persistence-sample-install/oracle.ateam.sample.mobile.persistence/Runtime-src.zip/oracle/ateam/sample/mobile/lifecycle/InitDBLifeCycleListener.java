/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 06-feb-2013   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.lifecycle;

import java.util.List;

import oracle.adfmf.application.LifeCycleListener;

import oracle.adfmf.framework.api.AdfmfJavaUtilities;

import oracle.ateam.sample.mobile.persistence.db.DBConnectionFactory;
import oracle.ateam.sample.mobile.persistence.manager.DBPersistenceManager;
import oracle.ateam.sample.mobile.persistence.service.DataSynchManager;
import oracle.ateam.sample.mobile.util.ADFMobileLogger;


/**
 * This class can be used as Lifecycle listener or can be extended by your own life cycle listener.
 * In the start method it will check whether a local database exists on your mobile device, and if it doesn't
 * it will create the database.
 * The check for the database is done by querying an arbitrary table in the application.
 * If an error is thrown the database is created.
 * To figure out the table name to use for the check, the (toplink) persistence mapping XML file is used.
 * This file should be located inside your ApplicationController project, and the file name and path of the
 * XML mapping file should be specified in mobile-persistence-config.properties. This properties file
 * should be located in the META-INF folder of your ApplicationController project.
 * The database connection details, and the script to create the database should also be specified in
 * mobile-persistence-config.properties. Here is an example of the entries that must be present
 * in the property file to make this InitDBLifeCycleListener class work correctly:
 * <pre>
 * db.name=HR.db
 * persistence.mapping.xml=META-INF/tlMap.xml
 * ddl.script=META-INF/hr.sql
 * </pre>
 *
 *  
 */
public class InitDBLifeCycleListener
  implements LifeCycleListener
{
  private static ADFMobileLogger sLog = ADFMobileLogger.createLogger(InitDBLifeCycleListener.class);

  public InitDBLifeCycleListener()
  {
  }

  /**
   * The start method will be called at the start of the application.
   * This method created the SQLLite database if needed. The actual work
   * is delegated to DBPersistenceManager.initIfNeeded.
   *
   * NOTE:
   * 1. This is a <b>blocking</b> call and will freeze the user interface
   *    while the method is being executed.  If you have any longer running
   *    items you should create a background thread and do the work there.
   * 2. Only the application controller's classes will be available in this
   *    method.
   */
  public void start()
  {
    sLog.fine("Excuting InitDBLifeCycleListener.start method");
    DBPersistenceManager pm= new DBPersistenceManager();
    pm.initDBIfNeeded();
  }

  /**
   * The stop method will be called at the termination of the application.
   *
   * NOTE:
   * 1. Depending on how the application is being shutdown, this method may
   *    or may not be called. For example, if a user kills the Application from
   *    the iOS multitask UI then stop will not be called.  Because of this, each
   *    feature should save off their state in the deactivate handler.
   * 2. Only the application controller's classes will be available in this
   *    method.
   */
  public void stop()
  {
    // Add code here...
  }

  /**
   * The activate method will be called when the application is started (post
   * the start method) and when an application is resumed by the operating
   * system.
   *
   * NOTE:
   * 1. This is a <b>blocking</b> call and will freeze the user interface
   *    while the method is being executed.  If you have any longer running
   *    items you should create a background thread and do the work there.
   * 2. Only the application controller's classes will be available in this
   *    method.
   */
  public void activate()
  {
    // Add code here...
  }

  /**
   * Deactivate method closes the DB connection if needed.
   * 
   * The deactivate method will be called as part of the application shutdown
   * process or when the application is being deactivated/hibernated by the
   * operating system.
   *
   * NOTE:
   * 1. This is a <b>blocking</b> call and will freeze the user interface
   *    while the method is being executed.  If you have any longer running
   *    items you should create a background thread and do the work there.
   * 2. Only the application controller's classes will be available in this
   *    method.
   */
  public void deactivate()
  {
    DBConnectionFactory.closeConnectionIfNeeded();
//    List syncManagers = DataSynchManager.getRegisteredDataSynchManagers();
//    if (syncManagers!=null)
//    {
//      for (int i = 0; i < syncManagers.size(); i++)
//      {
//        DataSynchManager dsm = (DataSynchManager) syncManagers.get(i);
//        dsm.saveSynchActionsToFile();
//      }
//    }  
  }

}
