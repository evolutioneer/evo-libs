package oracle.ateam.sample.mobile.model.bean;

import com.sun.util.logging.Level;

import java.lang.reflect.Method;

import java.util.Iterator;
import java.util.Map;

import oracle.adfmf.bindings.BindingContainer;
import oracle.adfmf.bindings.DataControl;
import oracle.adfmf.dc.DataProviderManager;
import oracle.adfmf.dc.GenericJavaBeanDataControlAdapter;
import oracle.adfmf.dc.bean.ConcreteJavaBeanObject;
import oracle.adfmf.dc.bean.ConcreteJavaBeanObjectBase;
import oracle.adfmf.dc.bean.ConcreteJavaCollectionObject;
import oracle.adfmf.framework.event.DataChangeProvider;
import oracle.adfmf.framework.exception.AdfException;
import oracle.adfmf.java.beans.ProviderChangeEvent;
import oracle.adfmf.metadata.page.BeanBindingIteratorBaseDefinition;
import oracle.adfmf.resource.CDCErrorBundle;
import oracle.adfmf.resource.CDCInfoBundle;
import oracle.adfmf.util.GenericType;
import oracle.adfmf.util.GenericTypeIteratorAdapter;
import oracle.adfmf.util.ResourceBundleHelper;
import oracle.adfmf.util.Utility;
import oracle.adfmf.util.XmlAnyDefinition;
import oracle.adfmf.util.logging.Trace;

public class MyGenericTypeIteratorAdapter
  extends GenericTypeIteratorAdapter
{
  public MyGenericTypeIteratorAdapter(DataControl dataControl, XmlAnyDefinition xmlAnyDefinition,
                                      BindingContainer bindingContainer, GenericType genericType)
  {
    super(dataControl, xmlAnyDefinition, bindingContainer, genericType);
  }

  public MyGenericTypeIteratorAdapter()
  {
    super();
  }

  /**
   * Ovewrridden method to work around ADF Mobile bug, sometimes this method is called
   * with null key causing exception to be thrown. Work around is to return -1 as index when
   * key is null
   * @param key
   * @return
   */
  public int getIndexFromKey(Object key)
  {
    if (key==null)
    {
      return -1;
    }
    return super.getIndexFromKey(key);
  }

//  public Object createRowWithData(Object provider, boolean insertFlag)
//  {
//    return createRowWithDataInternal(provider, insertFlag);
//  }
//
//  private synchronized Object createRowWithDataInternal(Object provider, boolean insertFlag)
//  {
//    GenericType newRow = null;
//    try
//    {
//      newRow = (GenericType) this.dc.createDataProvider(this.getMetadataDefinition());
//    }
//    catch (AdfException ex)
//    {
//      if (Utility.FrameworkLogger.isLoggable(Level.WARNING))
//      {
////        Trace.log(Utility.FrameworkLogger, Level.WARNING, this.getClass(), "createRowWithData",
////          ResourceBundleHelper.CDC_INFO_BUNDLE, CDCInfoBundle.MSG_DATACONTROL_CANNOT_CREATE_PROVIDER, 
////          new Object[] {this.dc.getName()});
//      }
//      throw ex;
//    }
//    
//    if (provider instanceof Map)
//    {
//      for (Iterator providerAttributes = ((Map) provider).keySet().iterator(); providerAttributes.hasNext();)
//      {
//        String attrName = (String) providerAttributes.next();
//        Object value = ((Map) provider).get(attrName);
//        if (this.isUpdateable(attrName))
//        {
//          newRow.setAttribute(attrName, value);
//        }
//      }
//    }
//    else
//    {
//      if (provider != null)
//      {
//        throw new IllegalArgumentException(Utility.getResourceString(
//          ResourceBundleHelper.CDC_ERROR_BUNDLE,
//          CDCErrorBundle.EXC_PROVIDER_DATA_MUST_BE_A_MAP,
//          new Object[] { "GenericTypeIteratorAdapter:createRowWithData()" }));
//      }
//    }
//
//    Object returnProvider = null;
//    if (insertFlag)
//    {
//      GenericType parent = this.getBaseProviderFromManager().getParent();
//      try
//      {
//        returnProvider =  insertChild(this.getBinds(), this.index, newRow);
//      }
//      catch (Exception e)
//      {
//        // TODO: Add catch code
//        e.printStackTrace();
//      }
//      if (returnProvider != null)
//      {
//        /* If we get a non null return value, this indicates the insert was successful.
//         * At this point, fire a provider create event from the parent.
//         * This will propagate up through the data provider manager and fix up provider references
//         * as necessary if any accessor wrapper instance have changed, as well as source the create
//         * event for any bindings associated with this and any other iterators on this provider collection.
//         */
//        if (parent instanceof ConcreteJavaCollectionObject)
//        {
//          parent = parent.getParent();  
//        }
//        if (parent instanceof DataChangeProvider)
//        {
//          ((DataChangeProvider) parent).fireProviderChange(new ProviderChangeEvent(ProviderChangeEvent.OPERATION_CREATE,
//            this.getBinds(), this.getProviderKey(returnProvider, this.index), returnProvider));
//        }
//      }
//      else
//      {
//        if (Utility.FrameworkLogger.isLoggable(Level.WARNING))
//        {
////          Trace.log(Utility.FrameworkLogger, Level.WARNING, this.getClass(), "createRowWithData",
////            ResourceBundleHelper.CDC_INFO_BUNDLE, CDCInfoBundle.MSG_DATACONTROL_CANNOT_INSERT_PROVIDER, 
////            new Object[] {this.dc.getName()});
//        }
//        returnProvider = newRow;
//      }
//    }
//    else
//    {
//      returnProvider = newRow;
//    }
//    
//    if (returnProvider instanceof ConcreteJavaBeanObject)
//    {
//      ConcreteJavaBeanObject cjbo = (ConcreteJavaBeanObject) returnProvider;
//      returnProvider = cjbo.getInstance();
//    }
//
//    return returnProvider;   
//  }

  

  private GenericType getBaseProviderFromManager()
  {
    DataProviderManager pm = ((GenericJavaBeanDataControlAdapter) this.dc).getDataProviderManager();
    Object provider = pm.getDataProvider(this.bc.getName(), this.getId());
    return (GenericType) provider;
  }

  private String getBinds()
  {
    return ((BeanBindingIteratorBaseDefinition) getMetadataDefinition()).getBinds();
  }

//  public Object insertChild(String accessorName, int index, Object child)
//    throws ClassNotFoundException
//  {
//    ConcreteJavaBeanObject cjbo = (ConcreteJavaBeanObject) child;
//    GenericType parent2 = this.getBaseProviderFromManager().getParent();
//    ConcreteJavaBeanObjectBase parent = (ConcreteJavaBeanObjectBase) parent2.getParent();
//
//    // Hold on to the count before insertion
//    int preInsertCount = parent.getAttributeCount(accessorName);
//
//    /*
//     * Look for an addT method, where T is the type of accessorName attribute,
//     * and invoke if possible. Note that since the child provider is already
//     * created, if there is a defined key attribute, and it is not set to a
//     * new unique value in its default constructor, then add method should set
//     * it.
//     */
//    Class declaredChildType = parent.getAttributeType(accessorName);
//    if (declaredChildType.isArray())
//    {
//      declaredChildType = declaredChildType.getComponentType();
//    }
//    String typeName = declaredChildType.getName();
//    String addMethodName = "add" + typeName.substring(typeName.lastIndexOf(".") + 1);
//
//    /*
//     * Note we first look for an addT method with an index parameter, if we
//     * cant find one we will fall back one that just takes the Object. (If
//     * neither is found we do nothing)
//     */
////    Class beanClass = Class.forName("oracle.demo.hrcrud.mobile.model.Department");
////    Class[] paramTypes = new Class[] { int.class, beanClass };
////    Object[] params = new Object[] { new Integer(index), cjbo.getInstance() };
////    Method m = Utility.getMethod(parent.beanInstance, addMethodName, paramTypes);
////    paramTypes = (m != null) ? paramTypes : new Class[] { beanClass };
////    params = (m != null) ? params : new Object[] { cjbo.getInstance() };
////    Utility.invokeIfPossible(parent.beanInstance, addMethodName, paramTypes, params);
//
//    // Check if the insert worked by looking at the attribute count again
//    if (parent.getAttributeCount(accessorName) <= preInsertCount)
//    {
//      return null;
//    }
//
//    return cjbo;
//  }

//  public Object getDataProvider(XmlAnyDefinition metadataDef)
//  {
//    Object aap = super.getDataProvider(metadataDef);
//    return aap;
//  }
//
//  public Object getWrappedDataProvider()
//  {
//    GenericJavaBeanDataControlAdapter dc = (GenericJavaBeanDataControlAdapter) getDataControl();
//    Object aap = dc.getWrappedDataProvider();
//    Object mies = super.getWrappedDataProvider();
//    boolean same = aap==mies;
//    if (mies==null)
//    {
//      return aap;
//    }
//    return mies;
//  }
}
