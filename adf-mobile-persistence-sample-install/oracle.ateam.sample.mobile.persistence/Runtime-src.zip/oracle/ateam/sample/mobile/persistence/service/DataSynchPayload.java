/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 22-jun-2013   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.service;

public class DataSynchPayload
{
  private DataSynchAction[] dataSynchActions;

  public DataSynchPayload()
  {
    super();
  }

  public void setDataSynchActions(DataSynchAction[] dataSynchActions)
  {
    this.dataSynchActions = dataSynchActions;
  }

  public DataSynchAction[] getDataSynchActions()
  {
    return dataSynchActions;
  }
}
