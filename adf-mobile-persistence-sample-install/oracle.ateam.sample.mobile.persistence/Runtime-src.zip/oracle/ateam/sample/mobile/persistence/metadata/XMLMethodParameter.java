/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 02-apr-2014   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.metadata;

import oracle.adfmf.util.XmlAnyDefinition;

/**
 * Implementation of SOAP method parameter or REST resource parameter that reads values from persistenceMapping.xml
 */
public class XMLMethodParameter extends XmlAnyDefinition implements MethodParameter
{

  public XMLMethodParameter(XmlAnyDefinition xmlAnyDefinition)
  {
    super(xmlAnyDefinition);
  }

  public String getName()
  {
    return (String) getAttributeValue("name");
  }

  public String getValueProvider()
  {
    return (String) getAttributeValue("valueProvider");
  }

  public String getDataObjectAttribute()
  {
    return (String) getAttributeValue("dataObjectAttribute");
  }

  public String getValue()
  {
    return (String) getAttributeValue("value");
  }

  public String getJavaType()
  {
    return (String) getAttributeValue("javaType");
  }

  public Class getJavaTypeClass()
  {
    String type = getJavaType();
    if (type==null)
    {
      type = "java.lang.String";
    }
    try
    {
      return Class.forName(type);
    }
    catch (ClassNotFoundException e)
    {
    }
    return String.class;
  }

  public boolean isLiteralValue()
  {
    return MethodParameter.LITERAL_VALUE.equals(getValueProvider());
  }

  public boolean isELExpression()
  {
    return MethodParameter.EL_EXPRESSION.equals(getValueProvider());
  }

  public boolean isDataObjectAttribute()
  {
    return MethodParameter.DATA_OBJECT_ATTRIBUTE.equals(getValueProvider());
  }

  public boolean isSerializedDataObject()
  {
    return MethodParameter.SERIALIZED_DATA_OBJECT.equals(getValueProvider());
  }

  public boolean isSearchValue()
  {
    return MethodParameter.SEARCH_VALUE.equals(getValueProvider());
  }

  public boolean isUriParam()
  {
    return "true".equals(getAttributeValue("uriParam"));
  }
  
}
