/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 02-apr-2014   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.metadata;

/**
 * Implementation of SOAP method parameter or REST resource parameter that can be instantiated programmatically
 */
public class MethodParameterImpl
  implements MethodParameter
{
  
  private String name;
  private String valueProvider;
  private String dataObjectAttribute;
  private String value;
  private String javaType;
  private boolean uriParam = false;

  public MethodParameterImpl(String name)
  {
    this.name= name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public String getName()
  {
    return name;
  }

  public void setValueProvider(String valueProvider)
  {
    this.valueProvider = valueProvider;
  }

  public String getValueProvider()
  {
    return valueProvider;
  }

  public void setDataObjectAttribute(String dataObjectAttribute)
  {
    this.dataObjectAttribute = dataObjectAttribute;
  }

  public String getDataObjectAttribute()
  {
    return dataObjectAttribute;
  }

  public void setValue(String value)
  {
    this.value = value;
  }

  public String getValue()
  {
    return value;
  }

  public void setJavaType(String javaType)
  {
    this.javaType = javaType;
  }

  public String getJavaType()
  {
    return javaType;
  }

  public MethodParameterImpl()
  {
    super();
  }


  public boolean isUriParam()
  {
    return uriParam;
  }

  public void setUriParam(boolean uriParam)
  {
    this.uriParam = uriParam;
  }


  public Class getJavaTypeClass()
  {
    String type = getJavaType();
    if (type==null)
    {
      type = "java.lang.String";
    }
    try
    {
      return Class.forName(type);
    }
    catch (ClassNotFoundException e)
    {
    }
    return String.class;
  }

  public boolean isLiteralValue()
  {
    return MethodParameter.LITERAL_VALUE.equals(getValueProvider());
  }

  public boolean isELExpression()
  {
    return MethodParameter.EL_EXPRESSION.equals(getValueProvider());
  }

  public boolean isDataObjectAttribute()
  {
    return MethodParameter.DATA_OBJECT_ATTRIBUTE.equals(getValueProvider());
  }

  public boolean isSerializedDataObject()
  {
    return MethodParameter.SERIALIZED_DATA_OBJECT.equals(getValueProvider());
  }

  public boolean isSearchValue()
  {
    return MethodParameter.SEARCH_VALUE.equals(getValueProvider());
  }

}
