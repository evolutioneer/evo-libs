package oracle.ateam.sample.mobile.persistence.metadata;

import java.util.ArrayList;
import java.util.List;

import oracle.adfmf.util.XmlAnyDefinition;

public class Method extends XmlAnyDefinition
{
  
  private List params = null;
  private List headerParams = null;
  
  public Method(XmlAnyDefinition xmlAnyDefinition)
  {
    super(xmlAnyDefinition);
  }
  
  public String getName()
  {
    return (String) getAttributeValue("name");
  }

  public String getDataControlName()
  {
    return (String) getAttributeValue("dataControlName");
  }

  public String getConnectionName()
  {
    return (String) getAttributeValue("connectionName");
  }

  public String getRequestType()
  {
    return (String) getAttributeValue("requestType");
  }
  
  public String getRequestUri()
  {
    return (String) getAttributeValue("uri");
  }

  public String getPayloadElementName()
  {
    return (String) getAttributeValue("payloadElementName");
  }

  public String getPayloadRowElementName()
  {
    return (String) getAttributeValue("payloadRowElementName");
  }

  public boolean isSecured()
  {
    return "true".equals(getAttributeValue("secured"));
  }

  public boolean isSendDataObjectAsPayload()
  {
    return "true".equals(getAttributeValue("sendDataObjectAsPayload"));
  }
      
  public List getParams()
  {
    if (params==null)
    {
      params = new ArrayList();
      List paramElems = getChildDefinitions("parameter");
      for (int i = 0; i < paramElems.size(); i++)
      {
        MethodParameter param = new XMLMethodParameter((XmlAnyDefinition) paramElems.get(i)); 
        params.add(param);
      }
    }
    return params;
  }

  public List getHeaderParams()
  {
    if (headerParams==null)
    {
      headerParams = new ArrayList();
      List paramElems = getChildDefinitions("header-parameter");
      for (int i = 0; i < paramElems.size(); i++)
      {
        MethodHeaderParameter param = new MethodHeaderParameter((XmlAnyDefinition) paramElems.get(i)); 
        headerParams.add(param);
      }
    }
    return headerParams;
  }
  
}
