/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 07-jan-2014   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.manager;

import java.util.List;

import oracle.adfmf.json.JSONObject;

import oracle.adfmf.util.Utility;
import oracle.adfmf.util.XmlAnyDefinition;

import oracle.ateam.sample.mobile.persistence.cache.EntityCache;
import oracle.ateam.sample.mobile.persistence.db.BindParamInfo;
import oracle.ateam.sample.mobile.persistence.metadata.AttributeMapping;
import oracle.ateam.sample.mobile.persistence.metadata.AttributeMappingDirect;
import oracle.ateam.sample.mobile.persistence.metadata.ClassMappingDescriptor;
import oracle.ateam.sample.mobile.persistence.metadata.Method;
import oracle.ateam.sample.mobile.persistence.model.Entity;
import oracle.ateam.sample.mobile.persistence.util.EntityUtils;
import oracle.ateam.sample.mobile.util.MessageUtils;

public abstract class AbstractRemotePersistenceManager
  extends AbstractPersistenceManager
  implements RemotePersistenceManager
{
  public static final String ACTION_INSERT = "insert";
  public static final String ACTION_UPDATE = "update";
  public static final String ACTION_MERGE = "merge";
  public static final String ACTION_REMOVE = "remove";

  DBPersistenceManager dBPersistenceManager = new DBPersistenceManager();
  
  public AbstractRemotePersistenceManager()
  {
    super();
  }

  public boolean isCreateSupported(Class clazz)
  {
    return ClassMappingDescriptor.getInstance(clazz).isCreateSupported();
  }

  public boolean isUpdateSupported(Class clazz)
  {
    return ClassMappingDescriptor.getInstance(clazz).isUpdateSupported();
  }

  public boolean isMergeSupported(Class clazz)
  {
    return ClassMappingDescriptor.getInstance(clazz).isMergeSupported();
  }

  public boolean isRemoveSupported(Class clazz)
  {
    return ClassMappingDescriptor.getInstance(clazz).isRemoveSupported();
  }

  public boolean isFindAllSupported(Class clazz)
  {
    return ClassMappingDescriptor.getInstance(clazz).isFindAllSupported();
  }

  public boolean isFindAllInParentSupported(Class clazz, String accessorAttribute)
  {
    return ClassMappingDescriptor.getInstance(clazz).isFindAllInParentSupported(accessorAttribute);
  }

  public boolean isGetAsParentSupported(Class clazz, String accessorAttribute)
  {
    return ClassMappingDescriptor.getInstance(clazz).isGetAsParentSupported(accessorAttribute);
  }

  public boolean isFindSupported(Class clazz)
  {
    return ClassMappingDescriptor.getInstance(clazz).isFindSupported();
  }

  /**
   * Do web service call that inserts or updates data of the entity passed in.
   * @param entity
   * @param doCommit
   */
  public void mergeEntity(Entity entity, boolean doCommit)
  {
    sendWriteRequest(entity, ClassMappingDescriptor.getInstance(entity.getClass()).getMergeMethod(),ACTION_MERGE);
  }

  /**
   * Do web service call that inserts data of the entity passed in.
   * @param entity
   * @param doCommit
   */
  public void insertEntity(Entity entity, boolean doCommit)
  {
    // there might be only a merge method, not an insert method
    ClassMappingDescriptor descriptor = ClassMappingDescriptor.getInstance(entity.getClass());
    Method method =
      descriptor.getCreateMethod() != null? descriptor.getCreateMethod(): descriptor.getMergeMethod();
    sendWriteRequest(entity, method,ACTION_INSERT);
  }

  /**
   * Do web service call that updates data of the entity passed in.
   * @param entity
   * @param doCommit
   */
  public void updateEntity(Entity entity, boolean doCommit)
  {
    // do merge action instead of update if possible. A merge action at ADF BC SDO service
    // can also insert new children, an update cannot.
    ClassMappingDescriptor descriptor = ClassMappingDescriptor.getInstance(entity.getClass());
    Method method =
      descriptor.isMergeSupported()? descriptor.getMergeMethod(): descriptor.getUpdateMethod();
    sendWriteRequest(entity, method,ACTION_UPDATE);
  }

  public void removeEntity(Entity entity, boolean doCommit)
  {
    ClassMappingDescriptor descriptor = ClassMappingDescriptor.getInstance(entity.getClass());
    sendRemoveRequest(entity, descriptor.getRemoveMethod());
  }

  public abstract void sendWriteRequest(Entity entity, Method method, String action);

  public abstract void sendRemoveRequest(Entity entity, Method method);

  protected void addParentPopulatedBindParamInfos(Class entityClass, List parentBindParamInfos, List bindParamInfos,
                                                  ClassMappingDescriptor descriptor)
  {
    if (parentBindParamInfos != null)
    {
      List mappings = descriptor.getAttributeMappingsDirectParentPopulated();
      for (int i = 0; i < mappings.size(); i++)
      {
        AttributeMappingDirect mapping = (AttributeMappingDirect) mappings.get(i);
        String parentAttr = mapping.getParentAttribute();
        // find corresponding parent bind param info
        BindParamInfo parentBindParamInfo = null;
        for (int j = 0; j < parentBindParamInfos.size(); j++)
        {
          BindParamInfo bpInfo = (BindParamInfo) parentBindParamInfos.get(j);
          if (bpInfo.getAttributeName().equals(parentAttr))
          {
            parentBindParamInfo = bpInfo;
            break;
          }
        }
        if (parentBindParamInfo != null)
        {
          BindParamInfo childBindParamInfo = constructBindParamInfo(entityClass, mapping);
          childBindParamInfo.setValue(parentBindParamInfo.getValue());
          bindParamInfos.add(childBindParamInfo);
        }
      }
    }
  }

  protected BindParamInfo createBindParamInfoFromPayloadAttribute(Class entityClass, AttributeMapping mapping,
                                                                  Object rawValue)
  {
    if (rawValue == null || "".equals(rawValue.toString().trim()) || rawValue==JSONObject.NULL)
    {
      return null;
    }
    BindParamInfo bpInfo = constructBindParamInfo(entityClass, mapping);
    Object convertedValue = rawValue;
    if (!mapping.isOneToOneMapping())
    {
      // no need to convert when 1:1 mapping because foreign key is typically String or Number type
      // and Number type can be inserted using string value
      try
      {
        convertedValue = EntityUtils.convertColumnValueToAttributeTypeIfNeeded(entityClass, mapping.getAttributeName(),
                                                                               rawValue);
      }
      catch (Exception e)
      {
        convertedValue = null;
        Class attrType = EntityUtils.getJavaType(entityClass, mapping.getAttributeName());
        // report to user that attribute has not been been converted properly
        MessageUtils.handleError("Error populating attribute " + mapping.getAttributeName() +
                                 ", cannot convert value " + rawValue + " of type " + rawValue.getClass().getName() +
                                 " to type " + attrType);
      }
    }
    bpInfo.setValue(convertedValue);
    return bpInfo;
  }

  protected void checkRequired(AttributeMapping attributeMapping, Object rawValue)
  {
    if (attributeMapping instanceof AttributeMappingDirect && ((AttributeMappingDirect)attributeMapping).isRequired())
    {
      if (rawValue == null || "".equals(rawValue.toString().trim()) || rawValue==JSONObject.NULL)
      {
        MessageUtils.handleError("Attribute "+attributeMapping.getAttributeName()+" is required, but is null in payload.");
      }      
    }
  }

  public void setDBPersistenceManager(DBPersistenceManager dBPersistenceManager)
  {
    this.dBPersistenceManager = dBPersistenceManager;
  }

  public DBPersistenceManager getDBPersistenceManager()
  {
    return dBPersistenceManager;
  }
  
  /**
   * Find a connection in connections.xml
   * @param name
   * @return
   */
  public XmlAnyDefinition findConnection(String name)
  {
    List connections = Utility.getConnections().getChildDefinitions("Reference");
    XmlAnyDefinition connection = null;
    for (int i = 0; i < connections.size(); i++)
    {
      XmlAnyDefinition currConnection = (XmlAnyDefinition) connections.get(i);
      if (name.equals(currConnection.getAttributeValue("name")))
      {
        connection = currConnection;
        break;
      }
    }
    return connection;
  }

  /**
   * Return true when the connection in connections.xml is secured
   * @param name
   * @return
   */
  public boolean isConnectionSecured(String name)
  {
    XmlAnyDefinition connection = findConnection(name);
    return (connection!=null && connection.getAttributeValue("credentialStoreKey")!=null);
  }

  /**
   * Create an entity instance from a list of bind param infos (which are really attribute infos).
   * If an entity instance with the same key already exists in the entity cache, this existing instance is
   * updated and returned. If no such instance is found, and the currentEntity passed is not null, it
   * implies that the primary key of the current entity is changed. In thst ase, the currentEntity is updated
   * with the new primary key, and the row with old key is removed from SQLite DB, and the cache is updated
   * with the new key pointing to the currentEntity instance.
   * @param entityClass
   * @param bindParamInfos
   * @return
   */
  protected Entity createOrUpdateEntityInstance(Class entityClass, List bindParamInfos, Entity currentEntity)
  {
    Entity newEntity = EntityUtils.getNewEntityInstance(entityClass);
    for (int i = 0; i < bindParamInfos.size(); i++)
    {
      BindParamInfo bpInfo = (BindParamInfo) bindParamInfos.get(i);
      newEntity.setAttributeValue(bpInfo.getAttributeName(), bpInfo.getValue());
    }
    // get the key of the new instance and check the cache, if an instance is already present in the cache
    // we need to update this instance and return it, instead of the new entity instance just created
    Entity existingEntity = EntityCache.getInstance().findByUID(entityClass, EntityUtils.getEntityKey(newEntity));
    if (existingEntity != null)
    {
      copyAttributeValues(existingEntity, newEntity);
      return existingEntity;
    }
    else if (currentEntity != null)
    {
      // pk has changed, update the old instance with values of new instance, so
      // changes are relected correctly in UI. Delete the row with the old PK from DB
      // a new row has already been added when processing the payload
      // update the cache with the new key pointing to the old instance
      refreshEntityKeyValuesIfNeeded(currentEntity, newEntity);
      return currentEntity;
    }
    else
    {
      // add new entity to cache
      EntityCache.getInstance().addEntity(newEntity);
      return newEntity;
    }
  }
}
