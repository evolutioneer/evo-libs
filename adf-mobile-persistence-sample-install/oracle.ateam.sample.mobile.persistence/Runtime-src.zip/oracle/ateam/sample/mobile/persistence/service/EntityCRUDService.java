/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 12-jun-2013   Steven Davelaar
 1.1           Implemented writes in background
 06-feb-2013   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import oracle.adf.model.datacontrols.device.DeviceManagerFactory;

import oracle.adfmf.framework.api.AdfmfJavaUtilities;
import oracle.adfmf.framework.exception.AdfException;

import oracle.ateam.sample.mobile.persistence.cache.EntityCache;
import oracle.ateam.sample.mobile.persistence.manager.DBPersistenceManager;
import oracle.ateam.sample.mobile.persistence.manager.PersistenceManager;
import oracle.ateam.sample.mobile.persistence.manager.RemotePersistenceManager;
import oracle.ateam.sample.mobile.persistence.metadata.AttributeMappingDirect;
import oracle.ateam.sample.mobile.persistence.metadata.ClassMappingDescriptor;
import oracle.ateam.sample.mobile.persistence.model.ChangeEventSupportable;
import oracle.ateam.sample.mobile.persistence.model.Entity;
import oracle.ateam.sample.mobile.persistence.util.EntityUtils;
import oracle.ateam.sample.mobile.util.ADFMobileLogger;
import oracle.ateam.sample.mobile.util.MessageUtils;
import oracle.ateam.sample.mobile.util.StringUtils;


/**
 * Abstract class that provides CRUD operations against two configurable persistence managers:
 * a local persistence manager and a remote persistence manager.
 * By default, this class uses the DBPersistenceManager as the local persistence manager to execute
 * CRUD operations against the SQLite database on the mobile device.
 * In addition, you can configure a remote persistence manager by calling setRemotePersistenceManager
 * in the constructor of your concrete subclass. When you define both a local and remote persistence manager,
 * then when the findAll method is called for the first time, it wll synchronize the local database with the
 * remote data source. You can also specify whether the remote CRUD actions are performed in the background so
 * the user can continue to work with his mobile app, orthat he needs to wait until the remote action has completed.
 *
 * By extending this class, you can store and retrieve data locally and synch with a remote data source with a
 * minimum of Java coding.
 * You only need to implement the abstract methods, and configure additional persistence managers as needed.
 * When you extend this class, you need to implement the abstract methods, and you need to add type-specific methods
 * to return the current list of entities and the current entity.
 * Here is an example of the methods that should be included in a concrete subclass:

<pre>
 protected Class getEntityClass()
 {
   return Department.class;
 }

 protected String getEntityListName()
 {
   return "departments";
 }

 public Department[] getDepartments()
 {
   Department[] departments =(Department[]) getEntityList().toArray(new Department[getEntityList().size()]);
   return departments;
 }

</pre>
 *
 * With this code in place, you can then turn your concrete CRUD service class into a data control, and use drag and drop
 * to build your mobile pages.
 */
public abstract class EntityCRUDService
  extends ChangeEventSupportable
{
  public static final String NETWORK_NOT_REACHABLE = "NotReachable"; // Indicates no network connectivity.
  private static ADFMobileLogger sLog = ADFMobileLogger.createLogger(EntityCRUDService.class);

  private transient DBPersistenceManager localPersistenceManager = new DBPersistenceManager();
  private transient RemotePersistenceManager remotePersistenceManager = null;
  private boolean autoCommit = true;
  //  private Entity currentEntity;
  private boolean firstRead = true;
  private boolean doRemoteReadInBackground = true;
  private boolean doRemoteWriteInBackground = true;
  private int lastNewEntityIndex = -1;
  private boolean autoGeneratePrimaryKey = true;

  private transient DataSynchManager dataSynchManager;

  /**
   * The current list of entities. All operations that filter, add or remove
   * entityList will change the content of this list.
   */
  private List entityList = new ArrayList();

  /**
   * Default constructor, also initializes the DataSynchManager which loads any pending data synch actions
   * from JSON file.
   */
  public EntityCRUDService()
  {
    super();
    // we call getDataSynchManager so any pending data synch actions are loaded from file
    // and processed just before the first read/write operation 
    getDataSynchManager();
  }

  /**
   * This method returns the type of the entity you want to have CRUD opertaions on.
   * @return
   */
  protected abstract Class getEntityClass();


  /**
   * This method returns the name of the property used to return the array of entity instances.
   * This name is used to automatically send change notifcations when the list of entities has been
   * changed so your mobile UI will automatically refresh.
   * For example, if you have a method getDepartments, this method should return "departments"
   * @return
   */
  protected abstract String getEntityListName();

  /**
   * Populates the entity list with all entities found.
   * When this method is called for the first time, and a remote persistence manager is configured,
   * the data is fetehced remotely and the local DB is populated with the results.
   */
  protected void findAll()
  {
    if (getLocalPersistenceManager()!=null)
    {
      entityList = getLocalPersistenceManager().findAll(getEntityClass());      
    }
    if ((firstRead || localPersistenceManager==null) && remotePersistenceManager != null && isOnline())
    {
      firstRead = false;
      // also do remote find in background!
      doRemoteFindAll();
    }
    setLastNewEntityIndex(-1);
  }

  /**
   * Populates the entity list with all entities thet have an attribute value that matches the searchValue.
   */
  protected void find(String searchValue)
  {
    if (getLocalPersistenceManager()!=null)
    {
      Entity[] oldEntityArray = getEntityListAsCorrectlyTypedArray();
      entityList = getLocalPersistenceManager().find(getEntityClass(), searchValue, getQuickSearchAttributeNames());
      refreshEntityList(oldEntityArray);
      setLastNewEntityIndex(-1);      
    }
    doRemoteFind(searchValue);
  }
  
  /**
   * Override this method to configure on which attributes the quick search (find method) will
   * be performed. By default, all String attributes are searchable.
   * @return
   */
  protected List getQuickSearchAttributeNames()
  {
    return null;
  }

  /**
   * Finds an entity instance using the key value
   * @param key
   * @return
   */
  protected Entity findEntityByKey(Object key)
  {
    Object[] keyValues = new Object[]{key};
    return findEntityByKey(keyValues);
  }

  /**
   * Finds an entity instance using the key value. This methid will first check the cache, and if not
   * foudn a nd a local persistence manager is defined, it will lookup the entity in the SQLite DB
   * @param key
   * @return
   */
  protected Entity findEntityByKey(Object[] key)
  {
    if (getLocalPersistenceManager()!=null)
    {
      return getLocalPersistenceManager().findByKey(getEntityClass(), key);      
    }
    else
    {
      return EntityCache.getInstance().findByUID(getEntityClass(), key);
    }
  }

  /**
   * Inserts an entity using the configured persistence managers.
   * If the insert is succesfull, the entity is added to the entity list, the entity new state is set to false and
   * method refreshEntityList is called to send change notifcations.
   * @param entity
   */
  protected void insertEntity(Entity entity)
  {
    validateEntity(entity);
    if (localPersistenceManager != null)
    {
      localPersistenceManager.insertEntity(entity, isAutoCommit());
    }
    if (remotePersistenceManager != null && remotePersistenceManager.isCreateSupported(entity.getClass()))
    {
      writeEntityRemote(new DataSynchAction(DataSynchAction.INSERT_ACTION, entity));
    }
    entity.setIsNewEntity(false);
    //  no longer add to list, this is already done wehn addEntity method is called through create operation
    //  addEntityToList(0,entity);
  }

  /**
   * Insert, update or remove an entity, or perform a custom action using the remote persistence manager
   * @param dataSynchAction the sync action 
   */
  protected void writeEntityRemote(DataSynchAction dataSynchAction)
  {
// no need to throw error, data synch actions will be registered and processed next time
//    if (getDataSynchManager().isDataSynchRunning())
//    {
//      throw new AdfException("Data sync currently running, try again later.",AdfException.ERROR);
//    }
    dataSynchAction.setIsNewEntity(true);
    dataSynchAction.setLastSynchAttempt(new Date());
    dataSynchAction.setLastSynchError(isOnline() ? (getDataSynchManager().isDataSynchRunning() ? "Previous data dynchronization still in progress" : null ) : "Device offline");
    getDataSynchManager().registerDataSynchAction(dataSynchAction);
    if (isOnline())
    {
      getDataSynchManager().synchronize(isDoRemoteWriteInBackground());
    }
  }    

 
  /**
   * Returns the value for which the current max key value needs to be
   * incremented to generate a new primary key value for a new row
   * @return
   */
  protected int getKeyValueIncrement()
  {
    return 1;
  }

  /**
   * Adds new entity to the list at the given index and sets entity status to new.
   * If autogeneratePrimaryKey is true, the key value is set based on the current max
   * key value in the underlying table and the value returned by getKeyValueIncrement
   * @param index
   * @param entity
   */
  protected void addEntity(int index, Entity entity)
  {
    setLastNewEntityIndex(index);
    entity.setIsNewEntity(true);
    //    Object oldEntityArray = getEntityListAsCorrectlyTypedArray();
    getEntityList().add(index, entity);
    // no longer need to fire change event, because we now create new instance through Create operation
    //    refreshEntityList(oldEntityArray);
    if (isAutoGeneratePrimaryKey())
    {
      generatePrimaryKeyValue(entity);
      EntityCache.getInstance().addEntity(entity);
    }
  }

  protected void generatePrimaryKeyValue(Entity entity)
  {
    EntityUtils.generatePrimaryKeyValue(getLocalPersistenceManager(),entity, getKeyValueIncrement());
  }

  /**
   * Updates an entity using the configured persistence managers.
   * @param entity
   */
  protected void updateEntity(Entity entity)
  {
    validateEntity(entity);
    if (localPersistenceManager != null)
    {
      localPersistenceManager.updateEntity(entity, isAutoCommit());
    }
    if (remotePersistenceManager != null && remotePersistenceManager.isUpdateSupported(entity.getClass()))
    {
      writeEntityRemote(new DataSynchAction(DataSynchAction.UPDATE_ACTION, entity));        
    }
  }

  /**
   * Performs a custom action using the configured remote persistence manager.
   * @param entity
   */
  protected void invokeCustomMethod(Entity entity, String methodName)
  {
    if (remotePersistenceManager != null)
    {
      DataSynchAction action = new DataSynchAction(DataSynchAction.CUSTOM_ACTION, entity);
      action.setCustomMethodName(methodName);
      writeEntityRemote(action);        
    }
  }

  /**
   * Inserts or updates an entity using the configured persistence managers.
   * The insert or update is determined by calling isNewEntity on the entity instance.
   * @param entity
   */
  protected void mergeEntity(Entity entity)
  {
    boolean isNew = entity.getIsNewEntity();
    // we could have called mergeEntity on persistence manager, but
    // on insert we want to reuse the refresh code in insertEntity method
    //    persistenceManager.mergeEntity(entity, isAutoCommit());
    if (isNew)
    {
      insertEntity(entity);
    }
    else
    {
      updateEntity(entity);
    }
  }

  /**
   * Removes an entity using the configured persistence managers if the entity state is not new.
   * If the remove is succesfull, the entity is removed from the entity list if found.
   * If the entity is not found in the list, this mmight be caused by the fact that the entity is new
   * (getIsNewEntity returns true) and no attributes have been set yet.
   * @param entity
   */
  protected void removeEntity(Entity entity)
  {
    if (!entity.getIsNewEntity())
    {
      if (localPersistenceManager != null)
      {
        localPersistenceManager.removeEntity(entity, isAutoCommit());
        EntityCache.getInstance().removeEntity(entity);
      }
      if (remotePersistenceManager != null && remotePersistenceManager.isRemoveSupported(entity.getClass()))
      {
        writeEntityRemote(new DataSynchAction(DataSynchAction.REMOVE_ACTION, entity));
      }
    }
    // no longer need to refresh the list, ADF Mobile framework takes care of this as long
    // as we use Delete operation from dc palette
    //   Object oldEntityArray = getEntityListAsCorrectlyTypedArray();
    boolean ok = getEntityList().remove(entity);
    if (!ok && entity.getIsNewEntity())
    {
      // if new entity does not have attrs filled in, it might not be found
      // ion that case see whetehr lasteNewEntityIndex is still pointing to new
      // entity, if so, remove it.
      if (getLastNewEntityIndex() > -1 && getEntityList().size() > getLastNewEntityIndex())
      {
        Entity entityToRemove = (Entity) getEntityList().get(getLastNewEntityIndex());
        if (entityToRemove.getIsNewEntity())
        {
          getEntityList().remove(0);
          ok = true;
        }
      }
    }
    //   if (ok)
    //   {
    //     refreshEntityList(oldEntityArray);
    //   }
  }

  /**
   * Helper method that returns the entity list as an array of the actual entity instances.
   * This method uses reflection to invoke the getter method in the concrete subclass, for
   * example getDepartments. The method name is derived from the value returned by method
   * getEntityListName().
   * @return
   */
  protected Entity[] getEntityListAsCorrectlyTypedArray()
  {
    try
    {
      Method getter = EntityUtils.getGetMethod(this.getClass(), getEntityListName());
      Entity[] value = (Entity[]) getter.invoke(this, null);
      return value;
    }
    catch (IllegalAccessException e)
    {
      throw new AdfException(e);
    }
    catch (InvocationTargetException e)
    {
      throw new AdfException(e);
    }
  }

  /**
   * Send change notifications when the content of the entity list changes
   * @param oldEntityArray
   */
  protected void refreshEntityList(Entity[] oldEntityArray)
  {
    boolean wasEmpty = oldEntityArray.length==0 || oldEntityArray.length==1 && oldEntityArray[0].isDummy();
    Entity[] newEntityArray = getEntityListAsCorrectlyTypedArray();
    getPropertyChangeSupport().firePropertyChange(getEntityListName(), oldEntityArray, newEntityArray);
    getProviderChangeSupport().fireProviderRefresh(getEntityListName());
    getPropertyChangeSupport().firePropertyChange("entityListIsEmpty", wasEmpty, getEntityListIsEmpty());
    getProviderChangeSupport().fireProviderRefresh("entityListIsEmpty");
    if (wasEmpty && newEntityArray.length>0 && !newEntityArray[0].isDummy())
    {
      newEntityArray[0].refreshDummy(true, false);
    }
  }

  /**
   * Set autoCommit flag. When set to true, the local DBPersistenceManager will issue a commit after each
   * INSERT, UPDATE or DELEET statement.
   * @param autoCommit
   */
  protected void setAutoCommit(boolean autoCommit)
  {
    this.autoCommit = autoCommit;
  }

  /**
   * Returns value of autoCommit flag. When set to true, the local DBPersistenceManager will issue a commit after each
   * INSERT, UPDATE or DELEET statement.
   * @param autoCommit
   */
  protected boolean isAutoCommit()
  {
    return autoCommit;
  }

  /**
   * Executes commit statement on the configured persistence managers.
   */
  protected void commit()
  {
    if (localPersistenceManager != null)
    {
      localPersistenceManager.commmit();
    }
    if (remotePersistenceManager != null && isOnline())
    {
      if (isDoRemoteWriteInBackground())
      {
        Runnable runnable = new Runnable()
        {
          public void run()
          {
            remotePersistenceManager.commmit();
          }
        };
        Thread thread = new Thread(runnable);
        thread.start();
      }
      else
      {
        remotePersistenceManager.commmit();
      }
    }
  }

  /**
   * Executes rollback statement on the configured persistence managers.
   * Also clears the entity cache for this entity type so that when a new query is executed,
   * no cached objects with stale data will be used.
   */
  protected void rollback()
  {
    if (localPersistenceManager != null)
    {
      localPersistenceManager.rollback();
    }
    if (remotePersistenceManager != null && isOnline())
    {
      if (isDoRemoteWriteInBackground())
      {
        Runnable runnable = new Runnable()
        {
          public void run()
          {
            remotePersistenceManager.rollback();
          }
        };
        Thread thread = new Thread(runnable);
        thread.start();
      }
      else
      {
        remotePersistenceManager.rollback();
      }
    }
    EntityCache.getInstance().clear(getEntityClass());
  }

  /**
   * Return the current list of entities. Method is protected to prevent it from showing
   * up in data control palette. You should add a public method to your subclass that converts this list
   * into a typed array, like this:
   * <pre>
   public Department[] getDepartments()
   {
     Department[] departments =(Department[]) getEntityList().toArray(new Department[getEntityList().size()]);
     return departments;
   }
   * </pre>
   * @return
   */
   protected List getEntityList()
   {
     return entityList;
   }

  protected boolean getEntityListIsEmpty()
  {
    return entityList.size()==0;
  }

  protected void setLocalPersistenceManager(DBPersistenceManager localPersistenceManager)
  {
    this.localPersistenceManager = localPersistenceManager;
  }

  protected DBPersistenceManager getLocalPersistenceManager()
  {
    return localPersistenceManager;
  }

  protected void setRemotePersistenceManager(RemotePersistenceManager remotePersistenceManager)
  {
    this.remotePersistenceManager = remotePersistenceManager;
  }

  protected RemotePersistenceManager getRemotePersistenceManager()
  {
    return remotePersistenceManager;
  }

  /**
   * Changes the current entity list. Calls refreshEntityList to ensure change notifcations
   * are sent to the UI.
   * @param entityList
   */
  protected void setEntityList(List entityList)
  {
    Entity[] oldEntityArray = getEntityListAsCorrectlyTypedArray();
    this.entityList = entityList;
    refreshEntityList(oldEntityArray);
  }

  /**
   *  Calls findAll on the remote persistence manager. Calling this method will effectively
   *  synchronize the local database table that is mapped to this entity with the remote data source.
   *  You can configure whether this action is performed in the background by calling setDoRemoteReadInBackground
   */
  protected void doRemoteFindAll()
  {
    if (getRemotePersistenceManager() == null)
    {
      sLog.fine("Cannot execute doRemoteFindAll, no remote persistence manager configured");
      return;
    }
    else if (!getRemotePersistenceManager().isFindAllSupported(getEntityClass()))
    {
      sLog.fine("Cannot execute doRemoteFindAll, no findAll method defined for entity "+getEntityClass().getName());
      return;
    }
    else if (isOffline())
    {
      sLog.fine("Cannot execute doRemoteFindAll, no network connection");
      return;
    }
    if (isDoRemoteReadInBackground())
    {
      Runnable runnable = new Runnable()
      {
        public void run()
        {
          // auto synch any pending actions first, pass false for inBackground because
          // we are already running in background thread
          getDataSynchManager().synchronize(false);
            List entities = remotePersistenceManager.findAll(getEntityClass());
          if (entities!=null)
          {
            // when an error occurs (for example server not available, the method returns null
            setEntityList(entities);        
            AdfmfJavaUtilities.flushDataChangeEvent();            
          }
        }
      };
      Thread thread = new Thread(runnable);
      thread.start();
    }
    else
    {
      // auto synch any pending actions first, pass false for inBackground because
      // we want to proces pending actions before we do remote read
      getDataSynchManager().synchronize(false);
      List entities = remotePersistenceManager.findAll(getEntityClass());
      if (entities!=null)
      {
        // when an error occurs (for example server not available, the method returns null
        setEntityList(entities);        
      }
    }
  }

  /**
   *  Calls findAllInParent on the remote persistence manager. 
   *  You can configure whether this action is performed in the background by calling setDoRemoteReadInBackground
   */
  protected void doRemoteFindAllInParent(final Entity parent, final String accessorAttribute)
  {
    if (getRemotePersistenceManager() == null)
    {
      sLog.fine("Cannot execute doRemoteFindAllInParent, no remote persistence manager configured");
      return;
    }
    else if (!getRemotePersistenceManager().isFindAllInParentSupported(getEntityClass(),accessorAttribute))
    {
      sLog.fine("Cannot execute doRemoteFindAllInParent, no findAllInParent method defined for entity "+getEntityClass().getName());
      return;
    }
    else if (isOffline())
    {
      sLog.fine("Cannot execute doRemoteFindAllInParent, no network connection");
      return;
    }
    if (isDoRemoteReadInBackground())
    {
      Runnable runnable = new Runnable()
      {
        public void run()
        {
          // auto synch any pending actions first, pass false for inBackground because
          // we are already running in background thread
          getDataSynchManager().synchronize(false);
          List entities = remotePersistenceManager.findAllInParent(getEntityClass(),parent,accessorAttribute);
          if (entities!=null)
          {
            // when an error occurs (for example server not available, the method returns null
            setEntityList(entities);        
          }
          AdfmfJavaUtilities.flushDataChangeEvent();
        }
      };
      Thread thread = new Thread(runnable);
      thread.start();
    }
    else
    {
      // auto synch any pending actions first, pass false for inBackground because
      // we want to proces pending actions before we do remote read
      getDataSynchManager().synchronize(false);
      List entities = remotePersistenceManager.findAllInParent(getEntityClass(),parent,accessorAttribute);
      if (entities!=null)
      {
        // when an error occurs (for example server not available, the method returns null
        setEntityList(entities);        
      }
    }
  }

  /**
   *  Calls findAll on the remote persistence manager. Calling this method will effectively
   *  synchronize the local database table that is mapped to this entity with the remote data source.
   *  You can configure whether this action is performed in the background by calling setDoRemoteReadInBackground
   */
  protected void doRemoteFind(final String searchValue)
  {
    if (getRemotePersistenceManager() == null)
    {
      sLog.fine("Cannot execute doRemoteFind, no remote persistence manager configured");
      return;
    }
    else if (!getRemotePersistenceManager().isFindSupported(getEntityClass()))
    {
      sLog.fine("Cannot execute doRemoteFind, no find method defined for entity "+getEntityClass().getName());
      return;
    }
    else if (isOffline())
    {
      sLog.fine("Cannot execute doRemoteFind, no network connection");
      return;
    }
    if (isDoRemoteReadInBackground())
    {
      Runnable runnable = new Runnable()
      {
        public void run()
        {
          // auto synch any pending actions first, pass false for inBackground because
          // we are already running in background thread
          getDataSynchManager().synchronize(false);
          List entities = remotePersistenceManager.find(getEntityClass(),searchValue);
          if (entities!=null)
          {
            // when an error occurs (for example server not available, the method returns null
            setEntityList(entities);        
          }
          AdfmfJavaUtilities.flushDataChangeEvent();
        }
      };
      Thread thread = new Thread(runnable);
      thread.start();
    }
    else
    {
      // auto synch any pending actions first, pass false for inBackground because
      // we want to proces pending actions before we do remote read
      getDataSynchManager().synchronize(false);
      List entities = remotePersistenceManager.find(getEntityClass(),searchValue);
      if (entities!=null)
      {
        // when an error occurs (for example server not available, the method returns null
        setEntityList(entities);        
      }
    }
  }

  protected void setDoRemoteReadInBackground(boolean doRemoteReadInBackground)
  {
    this.doRemoteReadInBackground = doRemoteReadInBackground;
  }

  protected boolean isDoRemoteReadInBackground()
  {
    return doRemoteReadInBackground;
  }

  protected void setDoRemoteWriteInBackground(boolean doRemoteWriteInBackground)
  {
    this.doRemoteWriteInBackground = doRemoteWriteInBackground;
  }

  protected boolean isDoRemoteWriteInBackground()
  {
    return doRemoteWriteInBackground;
  }

  protected void setLastNewEntityIndex(int lastNewEntityIndex)
  {
    this.lastNewEntityIndex = lastNewEntityIndex;
  }

  protected int getLastNewEntityIndex()
  {
    return lastNewEntityIndex;
  }

  protected boolean isOffline()
  {
//    String status = (String) AdfmfJavaUtilities.evaluateELExpression("#{deviceScope.hardware.networkStatus}");
    String status = DeviceManagerFactory.getDeviceManager().getNetworkStatus();
    boolean offline = NETWORK_NOT_REACHABLE.equals(status) || "unknown".equals(status);
//    boolean offline2 = NETWORK_NOT_REACHABLE.equals(status);
//    if (offline!=offline2)
//    {
//      MessageUtils.handleError("Not same, EL value: "+offline2);
//    }
    return offline;
  }

  protected boolean isOnline()
  {
    return !isOffline();
  }

  protected DataSynchManager getDataSynchManager()
  {
    if (dataSynchManager == null)
    {
      dataSynchManager = new DataSynchManager(this);
    }
    return dataSynchManager;
  }

  protected void setAutoGeneratePrimaryKey(boolean autoGeneratePrimaryKey)
  {
    this.autoGeneratePrimaryKey = autoGeneratePrimaryKey;
  }

  protected boolean isAutoGeneratePrimaryKey()
  {
    return autoGeneratePrimaryKey;
  }
  
  /**
   * This method validates the entity.
   * It checks for required attributes. Override this method to add additional custom validations.
   * You can call entity.getIsNewEntity() to determine whether the entity will ne inserted or updated.
   * When using a validationGroup and validationBehavior in the amx page, all empty fields are set to
   * an empty string, this method first changes these attrbute values to null as it should.
   * @param entity
   */
  protected void validateEntity(Entity entity)
  {    
    ClassMappingDescriptor descriptor = ClassMappingDescriptor.getInstance(entity.getClass());
    List mappings = descriptor.getAttributeMappingsDirect();
    List attrNames = new ArrayList();
    for (int i = 0; i < mappings.size(); i++)
    {
      AttributeMappingDirect mapping = (AttributeMappingDirect) mappings.get(i);
      Object attributeValue = entity.getAttributeValue(mapping.getAttributeName());
      if ("".equals(attributeValue))
      {
        attributeValue = null;
        entity.setAttributeValue(mapping.getAttributeName(), null);
      }
      if (mapping.isRequired() && attributeValue == null)
      {
        attrNames.add(mapping.getAttributeName());
      }
    }
    if (attrNames.size()>0)
    {
      String listToString = StringUtils.listToString(attrNames, ", ");
      String verb = attrNames.size()==1 ? " is " : " are ";
      MessageUtils.handleError(listToString+verb+" required");     
    }
  }
  
  /**
   * Process any pending data synch actions
   * @param inBackground
   */
  protected void synchronize(Boolean inBackground)
  {
    getDataSynchManager().synchronize(inBackground.booleanValue());
  }

  protected void setFirstRead(boolean firstRead)
  {
    this.firstRead = firstRead;
  }

  protected boolean isFirstRead()
  {
    return firstRead;
  }
  
  protected void resetEntity(Entity entity)
  {
    if (getLocalPersistenceManager()!=null)
    {
      getLocalPersistenceManager().resetEntity(entity);
    }
  }

  /**
   * Invokes the getCanonical method on the remote persistence manager if this has not happened yet
   * for this instance during this application session. The corresponding row in the local database is also updated if
   * the entity is persistable.
   * @param entity
   */
  protected void getCanonical(Entity entity)
  {
    if (isOnline() && getRemotePersistenceManager()!=null && !entity.canonicalGetExecuted())
    {
      getRemotePersistenceManager().getCanonical(entity);
      if (getLocalPersistenceManager()!=null && ClassMappingDescriptor.getInstance(getEntityClass()).isPersisted())
      {
        getLocalPersistenceManager().mergeEntity(entity, true);        
      }
    }    
  }
  
  
}
