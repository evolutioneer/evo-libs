/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 02-feb-2014   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.metadata;

import oracle.adfmf.util.XmlAnyDefinition;

public class MethodHeaderParameter extends XmlAnyDefinition
{
  public MethodHeaderParameter(XmlAnyDefinition xmlAnyDefinition)
  {
    super(xmlAnyDefinition);
  }

  public String getName()
  {
    return (String) getAttributeValue("name");
  }

  public String getValue()
  {
    return (String) getAttributeValue("value");
  }
}
