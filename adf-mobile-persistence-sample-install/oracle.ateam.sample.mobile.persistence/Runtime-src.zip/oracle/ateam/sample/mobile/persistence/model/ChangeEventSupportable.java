/*******************************************************************************
 Copyright: see readme.txt
 
 $revision_history$
 06-feb-2013   Steven Davelaar
 1.0           initial creation
******************************************************************************/
package oracle.ateam.sample.mobile.persistence.model;

import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;
import oracle.adfmf.java.beans.ProviderChangeListener;
import oracle.adfmf.java.beans.ProviderChangeSupport;

import oracle.ateam.sample.mobile.util.ADFMobileLogger;


/**
 *  Abstract class that can be extended to support ADF Mobile change events
 *
 *   
 */
public abstract class ChangeEventSupportable
{
  private static ADFMobileLogger sLog = ADFMobileLogger.createLogger(ChangeEventSupportable.class);

  protected transient ProviderChangeSupport providerChangeSupport = new ProviderChangeSupport(this);
  protected transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

  public void addProviderChangeListener(ProviderChangeListener listener)
  {
    providerChangeSupport.addProviderChangeListener(listener);
  }

  public void removeProviderChangeListener(ProviderChangeListener listener)
  {
    providerChangeSupport.removeProviderChangeListener(listener);
  }

  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    propertyChangeSupport.addPropertyChangeListener(listener);
  }

  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    propertyChangeSupport.removePropertyChangeListener(listener);
  }

  protected ProviderChangeSupport getProviderChangeSupport()
  {
    return providerChangeSupport;
  }

  protected PropertyChangeSupport getPropertyChangeSupport()
  {
    return propertyChangeSupport;
  }
}

