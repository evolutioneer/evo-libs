package oracle.ateam.hr.soapdemo.model.common;

public interface CountriesViewSDO {

   public java.lang.String getCountryId();

   public void setCountryId(java.lang.String value);

   public java.lang.String getCountryName();

   public void setCountryName(java.lang.String value);

   public java.math.BigDecimal getRegionId();

   public void setRegionId(java.math.BigDecimal value);

   public java.util.List getLocationsView();

   public void setLocationsView(java.util.List value);


}

