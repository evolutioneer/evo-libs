package oracle.ateam.hr.soapdemo.model.common;

import org.eclipse.persistence.sdo.SDODataObject;

public class LocationsViewSDOImpl extends SDODataObject implements LocationsViewSDO {

   public static final int START_PROPERTY_INDEX = 0;

   public static final int END_PROPERTY_INDEX = START_PROPERTY_INDEX + 5;

   public LocationsViewSDOImpl() {}

   public java.lang.Integer getLocationId() {
      return new Integer(getInt(START_PROPERTY_INDEX + 0));
   }

   public void setLocationId(java.lang.Integer value) {
      set(START_PROPERTY_INDEX + 0 , value);
   }

   public java.lang.String getStreetAddress() {
      return getString(START_PROPERTY_INDEX + 1);
   }

   public void setStreetAddress(java.lang.String value) {
      set(START_PROPERTY_INDEX + 1 , value);
   }

   public java.lang.String getPostalCode() {
      return getString(START_PROPERTY_INDEX + 2);
   }

   public void setPostalCode(java.lang.String value) {
      set(START_PROPERTY_INDEX + 2 , value);
   }

   public java.lang.String getCity() {
      return getString(START_PROPERTY_INDEX + 3);
   }

   public void setCity(java.lang.String value) {
      set(START_PROPERTY_INDEX + 3 , value);
   }

   public java.lang.String getStateProvince() {
      return getString(START_PROPERTY_INDEX + 4);
   }

   public void setStateProvince(java.lang.String value) {
      set(START_PROPERTY_INDEX + 4 , value);
   }

   public java.lang.String getCountryId() {
      return getString(START_PROPERTY_INDEX + 5);
   }

   public void setCountryId(java.lang.String value) {
      set(START_PROPERTY_INDEX + 5 , value);
   }


}

