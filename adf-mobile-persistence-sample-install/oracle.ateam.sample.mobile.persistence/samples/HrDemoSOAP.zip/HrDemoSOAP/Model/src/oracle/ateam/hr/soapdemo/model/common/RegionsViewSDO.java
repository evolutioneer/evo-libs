package oracle.ateam.hr.soapdemo.model.common;

public interface RegionsViewSDO {

   public java.math.BigDecimal getRegionId();

   public void setRegionId(java.math.BigDecimal value);

   public java.lang.String getRegionName();

   public void setRegionName(java.lang.String value);

   public java.util.List getCountriesView();

   public void setCountriesView(java.util.List value);


}

