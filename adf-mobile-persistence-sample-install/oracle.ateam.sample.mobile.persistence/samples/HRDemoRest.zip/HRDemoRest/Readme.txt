ADF BC Rest Services
====================
This demo application exposes REST-XML and REST-JSON services to read and write departments.

The application has been deployed inside the Oracle network, so you can use the links below.

If you are not inside the Oracle network, you can deploy the application, and replace 
http://slc01qrl.us.oracle.com:7401 with your own host:port.

An easy tool to test the RESTful service is the Chrome REST Console: https://chrome.google.com/webstore/category/apps?hl=en

REST-JSON
=========
GET    http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/ReadDeps?PrettyPrinting=true
GET    http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/ReadDepsAndEmps?PrettyPrinting=true
PUT    http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/WriteDeps
REMOVE http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/RemoveDeps
GET    http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/ReadEmps?PrettyPrinting=true
PUT    http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/WriteEmps
REMOVE http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/json/RemoveEmps

REST-XML 
========
GET http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/xml/ReadDeps
GET http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/xml/ReadDepsAndEmps
PUT http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/xml/WriteDeps
GET http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/xml/ReadEmps
PUT http://slc01qrl.us.oracle.com:7401/hrdemorest/rest/xml/WriteEmps


The WriteDeps REST-XML service inserts,updates or deletes one or more departments depending on the XML payload.
Here is an example payload (paypoad param name = "xml"):

xml=<DepartmentsView>
      <!-- This will be an update since department with this id does exist -->
      <DepartmentsViewRow>
         <DepartmentId>10</DepartmentId>
         <DepartmentName>MyDepartment</DepartmentName>
      </DepartmentsViewRow>
      <!-- This will be an insert since it doesn't exist -->
      <DepartmentsViewRow>
         <DepartmentId>15</DepartmentId>
         <DepartmentName>NewDepartment</DepartmentName>
      </DepartmentsViewRow>
      <!-- This department will be deleted -->
      <DepartmentsViewRow bc4j-action="remove">
         <DepartmentId>20</DepartmentId>
      </DepartmentsViewRow>
   </DepartmentsView>


   <DepartmentsView>
      <DepartmentsViewRow>
         <DepartmentId>15</DepartmentId>
         <DepartmentName>NewDepartment</DepartmentName>
      </DepartmentsViewRow>
   </DepartmentsView>


The WriteDeps REST-JSON service inserts or updates one or more departments depending on the json payload.
Here is an example payload (payload forms param name = "json":

json={"DepartmentsView":[{"DepartmentId":"10","DepartmentName":"ChangedName"},{"DepartmentId":"15","DepartmentName":"NewDepartmentName"}]}

