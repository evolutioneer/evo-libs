package davelaar.demo.ui.dyntab;


import davelaar.demo.ui.util.JsfUtils;
import davelaar.demo.ui.view.dyntab.DynTab;
import davelaar.demo.ui.view.dyntab.DynTabContext;

import javax.annotation.PostConstruct;


public class DynTabState
{
  private DynTab dynTab;
  private DynTabContext dynTabContext;
  
  public DynTabState()
  {
    super();
  }
  
  public static DynTabState getCurrentInstance()
  {
    return (DynTabState) JsfUtils.getExpressionValue("#{pageFlowScope.jhsDynTabState}");    
  }

  public void setDynTab(DynTab dynTab)
  {
    this.dynTab = dynTab;
  }

  public DynTab getDynTab()
  {
    return dynTab;
  }
  
  @PostConstruct
  public void initialize()
  {
    if (getDynTabContext()!=null)
    {
      setDynTab(getDynTabContext().getSelectedTab());          
    }
  }

  public void setDynTabContext(DynTabContext dynTabContext)
  {
    this.dynTabContext = dynTabContext;
  }

  public DynTabContext getDynTabContext()
  {
    return dynTabContext;
  }
  
  public void markDirty(boolean isDirty)
  {
    if (getDynTabContext()!=null)
    {
      getDynTabContext().markTabDirty(getDynTab().getId(), isDirty);      
    }
  }
  public void changeLabel(String label)
  {
    if (getDynTabContext()!=null)
    {
      getDynTabContext().changeTabLabel(getDynTab().getId(), label);      
    }
  }
}
