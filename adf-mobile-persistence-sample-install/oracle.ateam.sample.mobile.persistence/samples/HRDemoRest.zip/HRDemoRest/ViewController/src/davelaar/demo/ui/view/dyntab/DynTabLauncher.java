package davelaar.demo.ui.view.dyntab;


import davelaar.demo.ui.controller.bean.TaskFlowConfigBean;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;

import javax.faces.event.ActionEvent;


public class DynTabLauncher implements Serializable
{

  private String label;
  private String taskFlowName;
  private String taskFlowId;
  private boolean replaceTab = true;
  private String tabUniqueIdentifier;
  private Map parameters =  new HashMap();

  public void launchTab(String taskFlowName)
  {
    setTaskFlowName(taskFlowName);
    launchTab();
  }

  /**
   * This method is called to open a new dynamic tab, or go to the existing tab for the same uniqueIdentifier when
   * replaceTab property is true. 
   * If the taskflow name is set, we lookup the taskflow config bean t set the label, taskFlowId if not yet set,
   * and to set the default parameters.
   */
  public void launchTab()
  {
    // lookup taskflow config bean for taskFlowId and default parameters and default label
    TaskFlowConfigBean configBean = TaskFlowConfigBean.getInstance(taskFlowName);
    if (configBean!=null)
    {
      if (getLabel()==null)
      {
        setLabel(configBean.getLabel());
      }
      if (getTabUniqueIdentifier()==null)
      {
        if (configBean.getTabUniqueIdentifier()!=null)
        {
          setTabUniqueIdentifier(configBean.getTabUniqueIdentifier());              
        }
        else if (configBean.getName()!=null)
        {
          setTabUniqueIdentifier(configBean.getName());              
        }
        else if (getParameters().size()>0)
        {
          // use first param value as unique identifier
          String value = getParameters().values().iterator().next().toString();
          setTabUniqueIdentifier(value);
        }
      }
      for (String paramName : configBean.getParams().keySet())
      {
        if (!getParameters().containsKey(paramName))
        {
          getParameters().put(paramName,configBean.getParams().get(paramName));          
        }
      }
      if (getTaskFlowId()==null)
      {
        setTaskFlowId(configBean.getTaskFlowId());
      }
    }
    
    try
    {
      DynTabContext tabContext = DynTabContext.getCurrentInstance();
      if (replaceTab)
      {
        tabContext.addOrSelectTab(getLabel(),
                                                          getTaskFlowId(),
                                                          getTabUniqueIdentifier(),
                                                          getParameters());
      }
      else
      {
        tabContext.addTab(getLabel(),
                                                  getTaskFlowId(),
                                                  getTabUniqueIdentifier(),
                                                  getParameters());
      }
    }
    catch (DynTabContext.TabOverflowException e)
    {
      e.handleDefault();
    }
  }

  public void launchTab(ActionEvent event)
  {

    launchTab();
  }

  /**
   * Always launch new tab, regardless of replaceTab setting. Otherwise similar to launchTab.
   *
   * @param event
   */
  public void launchNewTab(ActionEvent event)
  {

    boolean oldReplaceValue = isReplaceTab();
    setReplaceTab(false);
    launchTab();
    setReplaceTab(oldReplaceValue);
  }

  public void setLabel(String label)
  {

    this.label = label;
  }

  public String getLabel()
  {

    return label;
  }

  public void setTaskFlowName(String taskFlowId)
  {

    this.taskFlowName = taskFlowId;
  }

  public String getTaskFlowName()
  {

    return taskFlowName;
  }

  public void setReplaceTab(boolean replaceCurrentTab)
  {

    this.replaceTab = replaceCurrentTab;
  }

  public boolean isReplaceTab()
  {

    return replaceTab;
  }

  public void setTabUniqueIdentifier(String tabUniqueIdentifier)
  {

    this.tabUniqueIdentifier = tabUniqueIdentifier;
  }

  public String getTabUniqueIdentifier()
  {

    return tabUniqueIdentifier;
  }

  public void setParameters(Map parameters)
  {

    this.parameters = parameters;
  }

  public Map getParameters()
  {

    return parameters;
  }

  public void setTaskFlowId(String taskFlowId)
  {
    this.taskFlowId = taskFlowId;
  }

  public String getTaskFlowId()
  {
    return taskFlowId;
  }
}
