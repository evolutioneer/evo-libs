package davelaar.demo.ui.controller.bean;


import davelaar.demo.ui.util.JsfUtils;
import davelaar.demo.ui.util.RichClientUtils;

import java.io.Serializable;

import javax.el.MethodExpression;

import javax.faces.application.NavigationHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.jbo.ApplicationModule;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;


/**
 * This is a generic class that can be used to show an alert for pending changes dialog, and then based on user feedback on the
 * dialog, either do nothing, or execute the navigation action as specified on the action property of the UI command component
 * To use this class, specify a pageFlowScoped managed bean named something like "pendingChangesBean" and the specify the
 * actionListener property on the UI command component to invoke the handle method:
 * <pre>
 *  actionListener="#{pageFlowScope.pendingChangesBean.handle}"
 * </pre>
 * The action property of the UI command component might contain a method expression or just a hard-coded string as navigation
 * outcome. In the case of a method expression, the expression might reference EL context variables that are request specific,
 * meaning they are only available in the context of the original request that caused the pending changes alert to be shown.
 * If this is the case, the method expression is already invoked BEFORE the alert is shown, and we store the navigation
 * outcome in this bean. An example of a request specific method expression is the action property
 * for the menu items that use the XMLMenuModel: #{menuItem.doAction}. Since the "menuItem" variable is no longer available
 * when the user clicks Yes or No on the pending changes dialog, the method expression is invoked and the navigation outcome
 * stored before the pending changes popup is shown.
 * However, if the method expression is not request specific, it is not needed to invoke the method expression priot to showing
 * the popup. There might be situations where it is even undesirable to do this, for example when the method executed
 * redirects to another page (for example when performing a logoff action).  Then this redirection would occur before the alert
 * is shown. To determine whether the method expression should be invoked before or after the popup is shown, the
 * managed property methodExpressionRequestSpecific is used which defaults to true. Using an af:setActionListener on the
 * UI command component this property can be set to false if needed.
 * So, in case of a log off link, the UI Command component would be defined as follows:
 * <pre>
 *  &lt;af:commandLink id="mggl0" text="Log Off" visible="#{jhsUser!=null}"
 *         actionListener="#{pageFlowScope.pendingChangesBean.handle}"
 *         action="#{LogoutBean.logout}"&gt;
 *       &lt;af:setActionListener from="#{false}" to="#{pageFlowScope.pendingChangesBean.methodExpressionRequestSpecific}"/&gt;
 *  &lt;/af:commandLink&gt;
 * </pre>
 * The alertPopupId defaults to "pt:pendingChangesPopup", which is the id used in the sample page templates ("pt" is
 * the id of the template)
 *
 * @author Steven Davelaar
 */
public class PendingChangesBean implements Serializable, ActionListener
{
  private static final ADFLogger sLog = ADFLogger.createADFLogger(PendingChangesBean.class);
  private String alertPopupId = "pt:pendingChangesPopup";
  private String navigationOutcome;
  private MethodExpression methodExpression;
  boolean methodExpressionRequestSpecific = true;

  public PendingChangesBean()
  {
  }

  public void handle(MethodExpression methodExpression)
    throws AbortProcessingException
  {
    this.methodExpression = methodExpression;
    handle((ActionEvent) null);
  }

  public void handle(ActionEvent actionEvent)
    throws AbortProcessingException
  {
    sLog.info("Handle pending changes");
    this.navigationOutcome = null;
    FacesContext context = JsfUtils.getFacesContext();
    if (hasPendingChanges())
    {
      UIViewRoot viewRoot = context.getViewRoot();
      RichPopup popup =
        (RichPopup) viewRoot.findComponent(getAlertPopupId());
      if (popup != null)
      {
        // store menu item navigation outcome so we can execute it when users presses OK in dialog
        if (actionEvent != null)
        {
          setNavigationOutcome(actionEvent, context);
        }
        RichClientUtils.getInstance().showPopup(popup, null);
        FacesContext.getCurrentInstance().renderResponse();
        // we need to throw this exception to stop JSF from further processing the
        // invokeApplication phase, otherwise navigation will occur!
        // Calling renderResponse is not enough, this will
        // skip to render response phase AFTER current phase is finished!
        throw new AbortProcessingException();
      }
      else
      {
        sLog.info("Popup with id '" + getAlertPopupId() +
                   "' to show outstanding changes alert NOT found!");
      }
    }
    else
    {
      sLog.info("No pending changes");
    }
  }

  public void setNavigationOutcome(ActionEvent actionEvent,
                                    FacesContext context)
  {
    Object menuItemAction =
      actionEvent.getComponent().getAttributes().get("actionExpression");
    if (menuItemAction != null &&
        menuItemAction instanceof MethodExpression)
    {
      MethodExpression menuItemActionMethod =
        (MethodExpression) menuItemAction;
      if (isMethodExpressionRequestSpecific())
      {
        // we need to invoke the menu item action here to get hold of the navigation outcome.
        // We can't do it after the alert dialog has been shown, because then we have a new request with
        // no access to the menuItem object that is part of the method expression
        navigationOutcome =
            (String) menuItemActionMethod.invoke(context.getELContext(),
                                                 null);        
        methodExpression = null;
      }
      else
      {
        navigationOutcome = null;
        methodExpression = menuItemActionMethod;
        // reset to default!
        methodExpressionRequestSpecific = true;
      }
    }
    else if (menuItemAction != null && menuItemAction instanceof String)
    {
      navigationOutcome = (String) menuItemAction;
    }
  }

  public void setAlertPopupId(String alertPopupId)
  {
    this.alertPopupId = alertPopupId;
  }

  public String getAlertPopupId()
  {
    return alertPopupId;
  }

  /**
   * This method handles the pending changes alert: if the user presses OK/yes, we continue
   * with the originally requested user action, otherwise, we do nothing.
   * <p>
   * @param event
   * @throws AbortProcessingException
   * 
   */
  public void processDialogEvent(DialogEvent event)
    throws AbortProcessingException
  {
    // always close the dialog
    RichClientUtils.getInstance().hidePopup((RichPopup) event.getComponent().getParent());
    if (event.getOutcome() == DialogEvent.Outcome.cancel ||
        event.getOutcome() == DialogEvent.Outcome.no)
    {
      // do nothing;
      return;
    }
    else if (event.getOutcome() == DialogEvent.Outcome.ok ||
             event.getOutcome() == DialogEvent.Outcome.yes)
    {
      DCDataControl dc = getCurrentDataControl();
      if (dc!=null)
      {
        dc.rollbackTransaction();
        sLog.info("Rollback performed on "+dc.getName());        
      }
      // handle navigation or method invocation
      // navigation outcome can be null when action component has no action property set,
      if (navigationOutcome != null)
      {
        sLog.info("Continue with navigation");
        handleNavigation();
      }
      else if (methodExpression != null)
      {
        // call back to method expression passed into this bean
        methodExpression.invoke(JsfUtils.getFacesContext().getELContext(),
                                null);
      }
    }  
  }

  public void handleNavigation()
  {
    FacesContext context = JsfUtils.getFacesContext();
    NavigationHandler nh = context.getApplication().getNavigationHandler();
    nh.handleNavigation(context, null, navigationOutcome);
  }

  public void processAction(ActionEvent actionEvent)
    throws AbortProcessingException
  {
    handle(actionEvent);
  }

  public String execute()
  {
    handle((ActionEvent) null);
    return null;
  }

  public void setMethodExpression(MethodExpression methodExpression)
  {
    this.methodExpression = methodExpression;
  }

  public MethodExpression getMethodExpression()
  {
    return methodExpression;
  }

  public void setMethodExpressionRequestSpecific(boolean methodExpressionRequestSpecific)
  {
    this.methodExpressionRequestSpecific = methodExpressionRequestSpecific;
  }

  public boolean isMethodExpressionRequestSpecific()
  {
    return methodExpressionRequestSpecific;
  }
  
  /**
   * This method returns true when there are uncommitted changes in
   * the business service tier. It first checks for uncomitted changes
   * in the data control that is found through the Commit binding.
   * If no Commit binding is present in current page def (typically UIShell page def )
   * this method returns false
   * hasPendingChanges method
   * @return See description.
   */
  public boolean hasPendingChanges()
  {
    boolean hasChanges = false;
    DCDataControl dc = getCurrentDataControl();
    if (dc!=null)
    {
      ApplicationModule am = dc.getApplicationModule();
       hasChanges = ((am != null && am.getTransaction().isDirty()) ||
              dc.isTransactionModified() || dc.isTransactionDirty());
    }
    return hasChanges;
  }

  public DCDataControl getCurrentDataControl()
  {
    DCDataControl dc = null;
    if ( BindingContext.getCurrent()!=null)
    {
      DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
      if (bc!=null )
      {
        JUCtrlActionBinding ab = (JUCtrlActionBinding) bc.findCtrlBinding("Commit");
        if (ab!=null)
        {
          dc = ab.getDataControl();          
        }
        else
        {
          sLog.info("No current data control found because Commit binding is missing in "+bc.getName());
        }
      }      
    }
    return dc;
  }
  
}
