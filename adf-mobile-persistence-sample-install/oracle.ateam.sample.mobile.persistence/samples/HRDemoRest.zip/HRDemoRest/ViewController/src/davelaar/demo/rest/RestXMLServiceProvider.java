package davelaar.demo.rest;

import davelaar.demo.model.service.common.HRService;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;

import javax.ws.rs.QueryParam;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCDataControl;

@Path("xml")
public class RestXMLServiceProvider
{

  @GET
  @Path("ReadDeps")
  public String getDepts()
  {
    return getHRService().getDepartmentsAsXML();
  }

  @GET
  @Path("ReadDepsAndEmps")
  public String getDeptsWithEmps()
  {
    return getHRService().getDepartmentAndEmployeesAsXML();
  }

  @PUT
  @Path("WriteDeps")
  public String writeDeps(@FormParam("xml") String xml)
  {
    return getHRService().insertUpdateOrDeleteDepartments(xml);
  }
  
  @GET
  @Path("ReadEmps")
  public String getEmps()
  {
    return getHRService().getEmployeesAsXML();
  }

  @PUT
  @Path("WriteEmps")
  public String writeEmps(@FormParam("xml") String xml)
  {
    return getHRService().insertUpdateOrDeleteEmployees(xml);
  }

  private HRService getHRService()
  {
    DCDataControl dc = BindingContext.getCurrent().findDataControl("HRServiceDataControl");
    HRService service = (HRService) dc.getDataProvider();
    return service;    
  }

}
