package davelaar.demo.ui.view.dyntab;


import davelaar.demo.ui.util.JsfUtils;
import davelaar.demo.ui.util.RichClientUtils;

import java.io.Serializable;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

import oracle.adf.controller.TaskFlowId;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;
import oracle.adf.view.rich.event.ItemEvent;

import org.apache.myfaces.trinidad.event.DisclosureEvent;
import org.apache.myfaces.trinidad.model.ChildPropertyMenuModel;
import org.apache.myfaces.trinidad.model.MenuModel;


public class DynTabContext
  implements Serializable
{
  private static final ADFLogger sLog =
    ADFLogger.createADFLogger(DynTabContext.class);


  private static final String TAB_NOT_CLOSEABLE_MESSAGE_KEY =
    "TAB_NOT_CLOSEABLE";
  private static final String TOO_MANY_TABS_OPEN_MESSAGE_KEY =
    "TOO_MANY_TABS_OPEN";
  private DynTabTracker tabTracker;
  private transient UIComponent contentArea;
  private transient UIComponent tabsNavigationPane;
  private Map tabsDisclosed = new TabsDisclosed();
  private boolean doUpdateDocumentTitle = false;
  private transient RichPopup tabDirtyPopup;
  private String documentTitlePrefix = "";
  private String documentId = "doc0";


  public DynTabContext()
  {
  }

  /**
   * Returns a DynTabContext instance. This can be a subclass of DynTabContext
   * because the JSF expression #{viewScope.jhsDynTabContext} is evaluated to retrieve the instance. So,
   * the actual class defined in an ADF Taskflow through the managed bean
   * facility under key "viewScope.jhsDynTabContext" will be returned.
   * If no context is found, we also try to find it under pageFlowScope.jhsDynTabContext, because it might have been
   * passed as taskflow parameter.
   *
   * @return DynTabContext
   */
  public static DynTabContext getCurrentInstance()
  {
    // viewScope might not be available yet, which results in NPE when evaluating.
    // In this case, we just return null
    try
    {
      DynTabContext context =
        (DynTabContext) JsfUtils.getExpressionValue("#{viewScope.dynTabContext}");
      if (context == null)
      {
        context =
            (DynTabContext) JsfUtils.getExpressionValue("#{pageFlowScope.dynTabContext}");
      }
      return context;
    }
    catch (Exception e)
    {
      // do nothing
    }
    return null;
  }

  public TaskFlowId getEmptyTaskFlowId()
  {
    return getTabTracker().getEmptyTaskFlowId();
  }

  public void setMainContent(String taskflowId)
    throws TabContentAreaDirtyException
  {
    setMainContent(taskflowId, null);
  }

  public void setMainContent(String taskflowId,
                             Map<String, Object> parameters)
    throws TabContentAreaDirtyException
  {

    DynTab tab = getSelectedTab();
    if (tab != null)
    {
      if (tab.isDirty())
      {
        throw new TabContentAreaDirtyException();
      }

      tab.setTitle("");
      tab.setTaskflowId(TaskFlowId.parse(taskflowId));
    }
    setTabsRendered(false);
    refreshTabsAndContentArea();
  }

  public void addOrSelectTab(String localizedName, String taskflowId)
    throws TabOverflowException
  {

    addOrSelectTab(localizedName, taskflowId, null, null);
  }

  public void addOrSelectTab(String localizedName, String taskflowId,
                             String tabUniqueIdentifier)
    throws TabOverflowException
  {

    addOrSelectTab(localizedName, taskflowId, tabUniqueIdentifier, null);
  }

  public boolean addOrSelectTab(String localizedName, String taskflowId,
                                String tabUniqueIdentifier,
                                Map<String, Object> parameters)
    throws TabOverflowException
  {
    sLog.info("TaskflowId: " + taskflowId + ", tabUniqueIdentifier: " +
              tabUniqueIdentifier + ", params: " + parameters);

    DynTab tab = getMatchingTab(taskflowId, tabUniqueIdentifier);

    if (tab != null)
    {
      sLog.info("Matching existing tab found, select it");
      setSelectedTab(tab);
      return true;
    }
    else
    {
      sLog.info("No matching existing tab found, add new tab");
      addTab(localizedName, taskflowId, tabUniqueIdentifier, parameters);
      return false;
    }
  }

  public void addTab(String localizedName, String taskflowId)
    throws TabOverflowException
  {

    addTab(localizedName, taskflowId, null, null);
  }

  public void addTab(String localizedName, String taskflowId,
                     String tabUniqueIdentifier)
    throws TabOverflowException
  {

    addTab(localizedName, taskflowId, tabUniqueIdentifier, null);
  }

  public void addTab(String localizedName, String taskflowId,
                     Map parameters)
    throws TabOverflowException
  {

    addTab(localizedName, taskflowId, null, parameters);
  }

  public void addTab(String localizedName, String taskflowId,
                     String tabUniqueIdentifier, Map parameters)
    throws TabOverflowException
  {

    if (tabTracker.getNumActive() >= tabTracker.getMaxNumberOfTabs())
    {
      throw new TabOverflowException();
    }
    else
    {
      // The list of tabs doesn't get fragmented, so the first inactive tab always
      // shows as the right most tab.
      DynTab tab = getFirstInactiveTabOrThrow();
      tab.setTitle(localizedName);
      tab.setActive(true);
      tab.setTaskflowId(TaskFlowId.parse(taskflowId));
      tab.setUniqueIdentifier(tabUniqueIdentifier);
      // add the dyn tab context to the parentContext param
      // we cannot do this through managed property because we then
      // get a cyclic reference to jhsDynTabContext when one or more
      // tabs are displayed initially
      Map parentContext = (Map) parameters.get("parentContext");
      if (parentContext!=null)
      {
        sLog.info("Adding jhsDynTabContext to parentContext map");
        parentContext.put("jhsDynTabContext", this);
      }
      tab.setParameters(parameters);
      tabTracker.setNumActive(tabTracker.getNumActive() + 1);
      setSelectedTabId(tab.getId());
    }
  }

  private DynTab getFirstInactiveTabOrThrow()
  {
    // We can do this, because we always make sure that all active tabs are in the
    // front of the list.
    DynTab tab = tabTracker.getTabList().get(tabTracker.getNumActive());
    if (!tab.isActive())
    {
      return tab;
    }

    throw new IllegalStateException("TabList state is corrupted!");
  }

  public void markCurrentTabDirty(boolean isDirty)
  {

    markTabDirty(getSelectedTabId(), isDirty);
  }

  public void markTabDirty(String id, boolean isDirty)
  {
    DynTab tab = getTab(id);
    if (tab.isDirty()!=isDirty)
    {
      tab.setDirty(isDirty);
      refreshTabsNavigationPane();      
    }
  }

  public void changeTabLabel(String tabId, String label)
  {
    DynTab tab = getTab(tabId);
    tab.setTitle(label);
    refreshTabsNavigationPane();          
  }

  public void removeCurrentTab(boolean ignorePendingChanges)
  {
    removeTab(getSelectedTabId(), ignorePendingChanges);
  }

  public void removeCurrentTab()
  {
    removeTab(getSelectedTabId(), false);
  }

  public void removeTab(String id)
  {
    removeTab(id, false);
  }

  public boolean isTagSetDirty()
  {
    for (DynTab tab: tabTracker.getActiveTabList())
    {
      if (tab.isDirty())
      {
        return true;
      }
    }

    return false;
  }

  public boolean isCurrentTabDirty()
  {
    DynTab tab = getSelectedTab();
    return tab != null? tab.isDirty(): false;
  }

  public DynTab getSelectedTab()
  {
    String selectedTabId = getSelectedTabId();
    if (selectedTabId != null)
    {
      return getTab(selectedTabId);
    }
    return null;
  }

  public String getSelectedTabIdentifier()
  {
    DynTab tab = getSelectedTab();
    return tab != null? tab.getUniqueIdentifier(): "";
  }


  public void setTabsRendered(boolean render)
  {

    tabTracker.setTabsRendered(render);
  }

  public String getSelectedTabId()
  {
    return tabTracker.getSelectedTabId();
  }

  public boolean isTabsRendered()
  {

    return tabTracker.isTabsRendered();
  }

  public DynTab getMatchingTab(String taskflowId,
                               String tabUniqueIdentifier)
  {
    if (tabUniqueIdentifier == null)
    {
      return getFirstTabWithTaskFlowId(taskflowId);
    }

    for (DynTab tab: tabTracker.getActiveTabList())
    {
      if (tabUniqueIdentifier.equals(tab.getUniqueIdentifier()))
      {
        return tab;
      }
    }

    return null;
  }

  public DynTab getFirstTabWithTaskFlowId(String taskflowId)
  {
    for (DynTab tab: tabTracker.getActiveTabList())
    {
      if (tab.getTaskflowId().getFullyQualifiedName().equals(taskflowId))
      {
        return tab;
      }
    }

    return null;
  }


  public void setSelectedTabId(String id)
  {
    DynTab tab = getTab(id);

    if (tab == null)
    {
      throw new IllegalArgumentException("Tab: " + id + " unknown!");
    }

    setSelectedTab(tab);
  }

  public void setSelectedTab(DynTab tab)
  {
    tabTracker.setSelectedTabId(tab.getId());
    tab.setActive(true);
    refreshTabsAndContentArea();
    updateDocumentTitle();
  }

  public void updateDocumentTitle()
  {
    if (isDoUpdateDocumentTitle())
    {
      String js =
        "AdfPage.PAGE.findComponent('" + getDocumentId() + "').setTitle('" +
        getDocumentTitle() + "')";
      RichClientUtils.getInstance().writeJavaScriptToClient(js);
    }
  }

  public String getDocumentTitle()
  {
    String tabTitle =
      getSelectedTab() != null? getSelectedTab().getTitle(): "";
    return getDocumentTitlePrefix() + tabTitle;
  }

  public Map<String, DynTab> getTabMap()
  {
    return Collections.unmodifiableMap(tabTracker.getTabMap());
  }

  public int indexOf(DynTab tab)
  {
    return tabTracker.getTabList().indexOf(tab);
  }

  public DynTab getTabAt(int index)
  {
    return tabTracker.getTabList().get(index);
  }

  public DynTab getTab(String id)
  {
    return tabTracker.getTabMap().get(id);
  }

  public List<DynTab> getActiveTabList()
  {
    return Collections.unmodifiableList(tabTracker.getActiveTabList());
  }

  public MenuModel getTabMenuModel()
  {
    List<DynTab> tabList = tabTracker.getTabList();
    return new ChildPropertyMenuModel(tabList, "children",
                                      Collections.singletonList(tabList.indexOf(getSelectedTab())));

  }

  public void setTabsNavigationPane(UIComponent tabsNavigationPane)
  {

    this.tabsNavigationPane = tabsNavigationPane;
  }

  public UIComponent getTabsNavigationPane()
  {

    return tabsNavigationPane;
  }

  public void setContentArea(UIComponent contentArea)
  {

    this.contentArea = contentArea;
  }

  public UIComponent getContentArea()
  {

    return contentArea;
  }

  public void tabActivatedEvent(ActionEvent action)
  {
    UIComponent component = action.getComponent();
    String tabId = String.valueOf(component.getAttributes().get("tabId"));
    setSelectedTabId(tabId);
  }


  public void tabRemovedEvent(ActionEvent action)
  {
    removeCurrentTab();
    updateDocumentTitle();
  }

  public Map getTabDisclosed()
  {
    return tabsDisclosed;
  }

  public void tabActivatedEvent(DisclosureEvent action)
  {
    UIComponent component = action.getComponent();
    String tabId = String.valueOf(component.getAttributes().get("tabId"));
    setSelectedTabId(tabId);
  }

  protected void removeTab(String id, boolean force)
  {
    DynTab tab = getTab(id);
    if (tab == null)
    {
      throw new IllegalArgumentException("Tab: " + id + " unknown!");
    }

    removeTab(tab, force);
  }

  protected void removeTab(DynTab tab, boolean force)
  {
    if (!tab.isCloseable() && !force)
    {
      JsfUtils.getInstance().addMessage(TAB_NOT_CLOSEABLE_MESSAGE_KEY);
      return;
    }

    if (tab.isDirty() && !force)
    {
      RichClientUtils.getInstance().showPopup(getTabDirtyPopup(), null);
      return;
    }

    // Completely clear the tab.
    tab.setTaskflowId(getEmptyTaskFlowId());
    tab.setParameters(null);
    tab.setUniqueIdentifier(null);
    tab.setTitle("");
    tab.setActive(false);
    tab.setActivated(false);

    // Reduce the numActive count.
    tabTracker.setNumActive(tabTracker.getNumActive() - 1);

    // Make sure that all active tabs are in the front of the list. This will
    // prevent fragmentation of the tablist, so this will make everything a lot
    // easier.
    List<DynTab> tabList = tabTracker.getTabList();
    int oldIndex = tabList.indexOf(tab);
    tabList.add(tabList.remove(oldIndex));

    // Determine the tab that should be should be currently open (in case the current
    // tab was closed).
    if (tab.equals(getSelectedTab()) && tabTracker.getNumActive() > 0)
    {
      int newIndex = oldIndex;
      if (newIndex >= tabTracker.getNumActive())
      {
        newIndex = 0;
      }

      setSelectedTab(tabList.get(newIndex));
    }

    refreshTabsAndContentArea();
  }

  protected void refreshTabsNavigationPane()
  {
    sLog.info("Adding tabs navigation pane as partial target");
    addPartialTarget(getTabsNavigationPane());
  }

  protected void refreshTabsAndContentArea()
  {
    refreshTabsNavigationPane();
    refreshContentArea();
  }

  protected void refreshContentArea()
  {
    sLog.info("Adding tabs content area as partial target");
    addPartialTarget(getContentArea());
  }

  protected void addPartialTarget(UIComponent component)
  {

    if (component != null)
    {
      AdfFacesContext.getCurrentInstance().addPartialTarget(component);
    }
  }

  public DynTabTracker getTabTracker()
  {
    return tabTracker;
  }

  public void setTabTracker(DynTabTracker tabTracker)
  {
    this.tabTracker = tabTracker;
  }

  public void removeTab(ItemEvent itemEvent)
  {
    UIComponent component = itemEvent.getComponent();
    String tabId = String.valueOf(component.getAttributes().get("tabId"));
    removeTab(tabId);
  }

  public void setDoUpdateDocumentTitle(boolean doUpdateDocumentTitle)
  {
    this.doUpdateDocumentTitle = doUpdateDocumentTitle;
  }

  public boolean isDoUpdateDocumentTitle()
  {
    return doUpdateDocumentTitle;
  }

  public void setTabDirtyPopup(RichPopup tabDirtyPopup)
  {
    this.tabDirtyPopup = tabDirtyPopup;
  }

  public RichPopup getTabDirtyPopup()
  {
    return tabDirtyPopup;
  }

  public void handleDirtyTabDialog(DialogEvent event)
  {
    if (event.getOutcome() == DialogEvent.Outcome.ok ||
        event.getOutcome() == DialogEvent.Outcome.yes)
    {
      removeCurrentTab(true);
    }
  }

  public void setDocumentTitlePrefix(String documentTitlePrefix)
  {
    this.documentTitlePrefix = documentTitlePrefix;
  }

  public String getDocumentTitlePrefix()
  {
    return documentTitlePrefix;
  }

  public void setDocumentId(String documentId)
  {
    this.documentId = documentId;
  }

  public String getDocumentId()
  {
    return documentId;
  }

  public static final class TabContentAreaDirtyException
    extends Exception
  {

    public TabContentAreaDirtyException()
    {

    }
  }

  public static final class TabContentAreaNotReadyException
    extends RuntimeException
  {

    public TabContentAreaNotReadyException()
    {

    }
  }

  public final class TabOverflowException
    extends Exception
  {

    final DynTabContext this$0;

    public TabOverflowException()
    {

      super();
      this$0 = DynTabContext.this;
    }

    public void handleDefault()
    {
      JsfUtils.getInstance().addMessage(TOO_MANY_TABS_OPEN_MESSAGE_KEY);
    }
  }

  private class TabsDisclosed
    extends HashMap
  {
    public Object get(Object key)
    {
      if (key instanceof DynTab)
      {
        DynTab tab = (DynTab) key;
        return tab.equals(getSelectedTab());
      }
      return false;
    }
  }
}

