package davelaar.demo.ui.application;


import davelaar.demo.ui.controller.bean.DynamicRegionManager;
import davelaar.demo.ui.util.JsfUtils;
import davelaar.demo.ui.view.dyntab.DynTabLauncher;

import javax.faces.application.NavigationHandler;
import javax.faces.context.FacesContext;

import oracle.adf.share.logging.ADFLogger;

import org.apache.myfaces.trinidadinternal.application.NavigationHandlerImpl;


public class RegionNavigationHandler
  extends NavigationHandlerImpl
{
  private static final ADFLogger sLog = ADFLogger.createADFLogger(RegionNavigationHandler.class);

  public RegionNavigationHandler(NavigationHandler navHandler)
  {
    super(navHandler);
  }

  /**
   * Overridden method
   * <ul>
   * <li>Store navigation action and successOutcome on request, so it can be used to
   * conditionally execute logic. </li>
   * <li>Call super</li>
   * <li>Set boolean jhsPageChanged request attribute to true when old and new ViewRoot
   * are different</li>
   * </ul>
   * @param FacesContext
   * @param action
   * @param outcome
   */
  public void handleNavigation(FacesContext facesContext, String action, String outcome)
  {
    sLog.info("handleNavigation action=" + action + ", outcome=" + outcome);
    if (outcome != null && outcome.startsWith("uishell:"))
    {
      int pos = outcome.indexOf(":");
      String shellAction = outcome.substring(0, pos);
      String regionName = outcome.substring(outcome.indexOf(":") + 1);
      sLog.info("Navigating to " + shellAction + ", with dynamic region " + regionName);
      // always set current task flow name, even if not changed, otherwise dynamic tab
      // is not shown when group is first in service
      getMainRegionManager().setCurrentTaskFlowName(regionName);
      // navigate using Shell action
      super.handleNavigation(facesContext, null, shellAction);
    }
    else if (outcome != null && outcome.startsWith("uishelldt:"))
    {
      int pos = outcome.indexOf(":");
      String shellAction = outcome.substring(0, pos);
      String regionName = outcome.substring(outcome.indexOf(":") + 1);
      sLog.info("Navigating to " + shellAction + ", and opening dynamic tab for region " + regionName);
      // always set current task flow name, even if not changed, otherwise dynamic tab
      // is not shown when group is first in service
      geDynTabLauncher().launchTab(regionName);
      // navigate using Shell action
      super.handleNavigation(facesContext, null, shellAction);
    }
    else
    {
      super.handleNavigation(facesContext, action, outcome);
    }
  }

  /**
   * Returns the PrimaryRegionManager for the current pageFlowScope.
   * This instance is not cached because we can have multiple pageFlowScopes,
   * e.g. when the user opens multiple browser windows.
   *
   * @return
   */
  public DynamicRegionManager getMainRegionManager()
  {
    return (DynamicRegionManager) JsfUtils.getExpressionValue("#{pageFlowScope.mainRegionManager}");
  }

  public DynTabLauncher geDynTabLauncher()
  {
    return (DynTabLauncher) JsfUtils.getExpressionValue("#{dynTabLauncher}");
  }

}

