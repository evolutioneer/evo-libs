package davelaar.demo.rest;

import davelaar.demo.model.service.common.HRService;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;

import javax.ws.rs.QueryParam;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCDataControl;

@Path("json")
public class RestJSONServiceProvider
{

  @GET
  @Path("ReadDeps")
  public String getDepts(@QueryParam("PrettyPrinting") String prettyPrinting)
  {
    boolean pp = "true".equals(prettyPrinting);
    return getHRService().getDepartmentsAsJSON(pp);
  }

  @GET
  @Path("ReadDepsAndEmps")
  public String getDeptsWithEmps(@QueryParam("PrettyPrinting") String prettyPrinting)
  {
    boolean pp = "true".equals(prettyPrinting);
    return getHRService().getDepartmentAndEmployeesAsJSON(pp);
  }

  @PUT
  @Path("WriteDeps")
  public String mergeDeps(@FormParam("json") String json)
  {
    return getHRService().mergeDepartments(json);
  }

  @DELETE
  @Path("RemoveDeps")
  public String removeDeps(@FormParam("json") String json)
  {
    return getHRService().deleteDepartments(json);
  }
  
  @GET
  @Path("ReadEmps")
  public String getEmps(@QueryParam("PrettyPrinting") String prettyPrinting)
  {
    boolean pp = "true".equals(prettyPrinting);
    return getHRService().getEmployeeAsJSON(pp);
  }

  @PUT
  @Path("WriteEmps")
  public String mergeEmps(@FormParam("json") String json)
  {
    return getHRService().mergeEmployees(json);
  }

  @DELETE
  @Path("RemoveEmps")
  public String removeEmps(@FormParam("json") String json)
  {
    return getHRService().deleteEmployees(json);
  }

  private HRService getHRService()
  {
    DCDataControl dc = BindingContext.getCurrent().findDataControl("HRServiceDataControl");
    HRService service = (HRService) dc.getDataProvider();
    return service;    
  }
}
