package mobile.model;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import oracle.ateam.sample.mobile.persistence.util.EntityUtils;
import oracle.ateam.sample.mobile.persistence.model.Entity;


public class Department
  extends Entity
{

  private Integer departmentId;
  private String departmentName;
  private Integer managerId;
  private Integer locationId;

  private transient List employeesViewList = createIndirectList("employeesViewList");
  // dummy attr to prevent child query during JSON serialization
  private transient Employee[] employeesView;


  public Integer getDepartmentId()
  {
    return this.departmentId;
  }

  public void setDepartmentId(Integer departmentId)
  {
    this.departmentId = departmentId;
  }

  public String getDepartmentName()
  {
    return this.departmentName;
  }

  public void setDepartmentName(String departmentName)
  {
    this.departmentName = departmentName;
  }

  public Integer getManagerId()
  {
    return this.managerId;
  }

  public void setManagerId(Integer managerId)
  {
    this.managerId = managerId;
  }

  public Integer getLocationId()
  {
    return this.locationId;
  }

  public void setLocationId(Integer locationId)
  {
    this.locationId = locationId;
  }


  public void setEmployeesViewList(List employeesViewList)
  {
    this.employeesViewList = employeesViewList;
  }

  /**
   * This method is called when entity instance is recreated from persisted JSON string in DataSynchAction
   */
  public void setEmployeesViewList(Employee[] employeesViewList)
  {
    this.employeesViewList = Arrays.asList(employeesViewList);
  }

  public List getEmployeesViewList()
  {
    return this.employeesViewList;
  }

  public Employee[] getEmployeesView()
  {
    List dataObjectList = getEmployeesViewList();
    if (dataObjectList.size() == 0)
    {
      // add dummy entity to work around bug that causes InvocationTargetException
      // when using Create operation on empty data object array.
      // In the AMX page, the list view should be hidden when current entity dummy attr is true
      dataObjectList = new ArrayList();
      dataObjectList.add(EntityUtils.getDummyEntityInstance(Employee.class));
    }
    return (Employee[]) dataObjectList.toArray(new Employee[dataObjectList.size()]);
  }

  public void addEmployee(int index, Employee employee)
  {
    employee.setIsNewEntity(true);
    EntityUtils.generatePrimaryKeyValue(employee, 1);
    employee.setDepartmentId(getDepartmentId());
    getEmployeesViewList().add(index, employee);
  }

  public void removeEmployee(Employee employee)
  {
    getEmployeesViewList().remove(employee);
  }


}
